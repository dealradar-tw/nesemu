# 紅白機模擬器（NesEmu）

以 KotNES 為藍本的 Android 原生（Kotlin）NES / Famicom 模擬器，介面為繁體中文。
模擬核心完全自行以 Kotlin 撰寫，不依賴任何第三方模擬器程式碼。

## 功能

- 6502 CPU（含常見非官方指令）、逐週期 PPU、APU（2 方波、三角波、噪音、DMC）
- Mapper：0 / 1 (MMC1) / 2 (UxROM) / 3 (CNROM) / 4 (MMC3) / 7 (AxROM) / 66 (GxROM)
- 觸控虛擬按鍵（十字鍵、A、B、選擇、開始，多點觸控），支援實體鍵盤 / 手把
- **連發**：畫面上的「連A」「連B」，按住即連發；速度可選 30 / 20 / 15 / 10 次/秒
- **遊戲加速**：「快轉」鍵切換，倍率可選 2 / 3 / 4 倍（快轉時靜音）
- **即時存取**：4 個欄位；「存檔」「讀檔」鍵使用目前欄位，選單可選欄位並顯示時間
- **金手指**：Game Genie 碼（6 或 8 碼字母）與 RAM 碼（`位址:數值`，例如 `0075:09`），每個遊戲各自保存、可個別開關
- **畫面旋轉**：可隨手機自動旋轉，也可鎖定直向 / 橫向；旋轉不中斷遊戲
- **畫面比例**：4:3、原始像素比例、16:9
- 電池存檔（SRAM）自動保存與載入

## 操作

- 返回鍵或畫面上的「選單」：開啟選單（開啟期間遊戲暫停）
- 鍵盤：方向鍵、X=A、Z=B、S=連A、A=連B、Enter=開始、右 Shift=選擇

## 建置

1. 用 Android Studio（Ladybug 以上）開啟本資料夾。
2. 等待 Gradle 同步完成後，連接手機或啟動模擬器，按「Run」。
3. 沒有電腦環境時，可用 `.github/workflows/build.yml` 在 GitHub Actions 雲端編譯 APK。

需求：JDK 17、Android SDK 35、minSdk 24（Android 7.0）。

## 專案結構

```
app/src/main/java/com/example/nesemu/
├── core/                 純 Kotlin 模擬核心（不依賴 Android）
│   ├── Cpu.kt            6502 CPU
│   ├── Ppu.kt            圖形處理器
│   ├── Apu.kt            音效處理器
│   ├── Bus.kt            位址匯流排、手把、金手指補丁
│   ├── Mapper.kt         卡帶 Mapper
│   ├── Cartridge.kt      iNES 檔頭解析
│   ├── Cheats.kt         金手指解碼（Game Genie / RAM 碼）
│   ├── StateIO.kt        存檔序列化輔助
│   └── Nes.kt            整機組合、逐格執行、存讀檔
└── ui/
    ├── MainActivity.kt       首頁
    ├── EmulatorActivity.kt   遊戲畫面與選單
    ├── EmulatorRunner.kt     模擬執行緒（畫面、音訊、連發、快轉、存檔）
    ├── GameView.kt           畫面繪製
    ├── ControlsView.kt       虛擬按鍵
    └── Settings.kt           設定、金手指與存檔檔案管理
```

## 法律提醒

本程式不附帶任何遊戲 ROM。請僅使用你合法擁有的遊戲備份。
