# 紅白機模擬器（NesEmu）

以 KotNES 為藍本的 Android 原生（Kotlin）NES / Famicom 模擬器，介面為繁體中文。
模擬核心完全自行以 Kotlin 撰寫，不依賴任何第三方模擬器程式碼。

## 目前進度（第一階段）

- [x] 6502 CPU（含常見非官方指令）
- [x] 逐週期 PPU（背景、精靈、捲動、Sprite 0 Hit）
- [x] APU（2 方波、三角波、噪音、DMC）
- [x] Mapper：0 / 1 (MMC1) / 2 (UxROM) / 3 (CNROM) / 4 (MMC3) / 7 (AxROM) / 66 (GxROM)
- [x] 繁體中文介面、選擇 ROM、最近遊玩
- [x] 觸控虛擬按鍵（十字鍵、A、B、選擇、開始，多點觸控）
- [x] 可隨手機旋轉（直向 / 橫向，旋轉不中斷遊戲）
- [x] 電池存檔（SRAM）自動保存與載入
- [x] 實體鍵盤 / 手把：方向鍵、X=A、Z=B、Enter=開始、右 Shift=選擇

## 第二階段（規劃中）

- [ ] 連發按鍵（A / B 連發、頻率可調）
- [ ] 遊戲加速（2x / 3x / 4x）
- [ ] 即時存檔 / 讀檔（多個欄位）
- [ ] 金手指（Game Genie 碼與 RAM 位址碼）
- [ ] 手動旋轉畫面、畫面比例設定、按鍵配置調整
- [ ] 設定頁面與暫停選單

## 建置

1. 用 Android Studio（Ladybug 以上）開啟本資料夾。
2. 等待 Gradle 同步完成後，連接手機或啟動模擬器，按「Run」。
3. 命令列（已安裝 Gradle 8.10 以上時）：`gradle assembleDebug`，APK 輸出於 `app/build/outputs/apk/debug/`。
   本專案未附 Gradle wrapper，Android Studio 開啟時會自動處理。

需求：JDK 17、Android SDK 35、minSdk 24（Android 7.0）。

## 專案結構

```
app/src/main/java/com/example/nesemu/
├── core/                 純 Kotlin 模擬核心（不依賴 Android）
│   ├── Cpu.kt            6502 CPU
│   ├── Ppu.kt            圖形處理器
│   ├── Apu.kt            音效處理器
│   ├── Bus.kt            位址匯流排、手把
│   ├── Mapper.kt         卡帶 Mapper
│   ├── Cartridge.kt      iNES 檔頭解析
│   └── Nes.kt            整機組合與逐格執行
└── ui/
    ├── MainActivity.kt       首頁
    ├── EmulatorActivity.kt   遊戲畫面
    ├── EmulatorRunner.kt     模擬執行緒（畫面、音訊、存檔）
    ├── GameView.kt           畫面繪製
    └── ControlsView.kt       虛擬按鍵
```

## 法律提醒

本程式不附帶任何遊戲 ROM。請僅使用你合法擁有的遊戲備份。
