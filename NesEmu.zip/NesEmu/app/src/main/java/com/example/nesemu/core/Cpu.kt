package com.example.nesemu.core

import java.io.DataInputStream
import java.io.DataOutputStream

/** 6502 CPU（含常見的非官方指令）。step() 執行一道指令並回傳花費的 CPU 週期數。 */
class Cpu(private val bus: Bus) {
    var a = 0
    var x = 0
    var y = 0
    var sp = 0xFD
    var pc = 0
    private var fc = false
    private var fz = false
    private var fi = true
    private var fd = false
    private var fv = false
    private var fn = false
    var cycles = 0L
        private set

    /** 診斷：遇到未支援指令的次數、最後一次的指令碼與位址。 */
    var unknownCount = 0
        private set
    var lastUnknownOp = -1
        private set
    var lastUnknownPc = 0
        private set

    private enum class M { IMP, ACC, IMM, ZP, ZPX, ZPY, ABS, ABX, ABY, IND, IZX, IZY, REL }

    private enum class I {
        ADC, AND, ASL, BCC, BCS, BEQ, BIT, BMI, BNE, BPL, BRK, BVC, BVS, CLC, CLD, CLI, CLV,
        CMP, CPX, CPY, DEC, DEX, DEY, EOR, INC, INX, INY, JMP, JSR, LDA, LDX, LDY, LSR, NOP,
        ORA, PHA, PHP, PLA, PLP, ROL, ROR, RTI, RTS, SBC, SEC, SED, SEI, STA, STX, STY,
        TAX, TAY, TSX, TXA, TXS, TYA, LAX, SAX, DCP, ISB, SLO, SRE, RLA, RRA,
    }

    fun reset() {
        a = 0; x = 0; y = 0
        sp = 0xFD
        fi = true; fc = false; fz = false; fd = false; fv = false; fn = false
        pc = bus.cpuRead(0xFFFC) or (bus.cpuRead(0xFFFD) shl 8)
    }

    fun step(): Int {
        if (bus.stall > 0) {
            val s = bus.stall
            bus.stall = 0
            cycles += s
            return s
        }
        if (bus.ppu.nmi) {
            bus.ppu.nmi = false
            return interrupt(0xFFFA)
        }
        if (!fi && (bus.apu.irq || bus.mapper.irq)) return interrupt(0xFFFE)

        val opPc = pc
        val op = fetch()
        if (!DEF[op]) {
            unknownCount++
            lastUnknownOp = op
            lastUnknownPc = opPc
        }
        val inst = INST[op]
        val mode = MODE[op]
        var cyc = CYC[op]
        var addr = 0
        when (mode) {
            M.IMM -> {
                addr = pc
                pc = (pc + 1) and 0xFFFF
            }
            M.ZP -> addr = fetch()
            M.ZPX -> addr = (fetch() + x) and 0xFF
            M.ZPY -> addr = (fetch() + y) and 0xFF
            M.ABS -> {
                val lo = fetch()
                addr = lo or (fetch() shl 8)
            }
            M.ABX -> {
                val lo = fetch()
                val base = lo or (fetch() shl 8)
                addr = (base + x) and 0xFFFF
                if (PEN[op] && (base and 0xFF00) != (addr and 0xFF00)) cyc++
            }
            M.ABY -> {
                val lo = fetch()
                val base = lo or (fetch() shl 8)
                addr = (base + y) and 0xFFFF
                if (PEN[op] && (base and 0xFF00) != (addr and 0xFF00)) cyc++
            }
            M.IND -> {
                val lo = fetch()
                val p = lo or (fetch() shl 8)
                val l = bus.cpuRead(p)
                val h = bus.cpuRead((p and 0xFF00) or ((p + 1) and 0xFF))
                addr = l or (h shl 8)
            }
            M.IZX -> {
                val z = (fetch() + x) and 0xFF
                addr = bus.cpuRead(z) or (bus.cpuRead((z + 1) and 0xFF) shl 8)
            }
            M.IZY -> {
                val z = fetch()
                val base = bus.cpuRead(z) or (bus.cpuRead((z + 1) and 0xFF) shl 8)
                addr = (base + y) and 0xFFFF
                if (PEN[op] && (base and 0xFF00) != (addr and 0xFF00)) cyc++
            }
            M.REL -> {
                val off = fetch().toByte().toInt()
                addr = (pc + off) and 0xFFFF
            }
            else -> {}
        }

        bus.cpuPre = if (cyc > 1) cyc - 1 else 0
        when (inst) {
            I.LDA -> { a = bus.cpuRead(addr); zn(a) }
            I.LDX -> { x = bus.cpuRead(addr); zn(x) }
            I.LDY -> { y = bus.cpuRead(addr); zn(y) }
            I.LAX -> { a = bus.cpuRead(addr); x = a; zn(a) }
            I.STA -> bus.cpuWrite(addr, a)
            I.STX -> bus.cpuWrite(addr, x)
            I.STY -> bus.cpuWrite(addr, y)
            I.SAX -> bus.cpuWrite(addr, a and x)
            I.TAX -> { x = a; zn(x) }
            I.TAY -> { y = a; zn(y) }
            I.TXA -> { a = x; zn(a) }
            I.TYA -> { a = y; zn(a) }
            I.TSX -> { x = sp; zn(x) }
            I.TXS -> sp = x
            I.AND -> { a = a and bus.cpuRead(addr); zn(a) }
            I.ORA -> { a = a or bus.cpuRead(addr); zn(a) }
            I.EOR -> { a = a xor bus.cpuRead(addr); zn(a) }
            I.ADC -> adc(bus.cpuRead(addr))
            I.SBC -> adc(bus.cpuRead(addr) xor 0xFF)
            I.CMP -> cmp(a, bus.cpuRead(addr))
            I.CPX -> cmp(x, bus.cpuRead(addr))
            I.CPY -> cmp(y, bus.cpuRead(addr))
            I.BIT -> {
                val m = bus.cpuRead(addr)
                fz = (a and m) == 0
                fv = (m and 0x40) != 0
                fn = (m and 0x80) != 0
            }
            I.INX -> { x = (x + 1) and 0xFF; zn(x) }
            I.INY -> { y = (y + 1) and 0xFF; zn(y) }
            I.DEX -> { x = (x - 1) and 0xFF; zn(x) }
            I.DEY -> { y = (y - 1) and 0xFF; zn(y) }
            I.INC -> {
                val r = (bus.cpuRead(addr) + 1) and 0xFF
                bus.cpuWrite(addr, r); zn(r)
            }
            I.DEC -> {
                val r = (bus.cpuRead(addr) - 1) and 0xFF
                bus.cpuWrite(addr, r); zn(r)
            }
            I.ASL -> {
                val v = if (mode == M.ACC) a else bus.cpuRead(addr)
                val r = asl(v)
                if (mode == M.ACC) a = r else bus.cpuWrite(addr, r)
            }
            I.LSR -> {
                val v = if (mode == M.ACC) a else bus.cpuRead(addr)
                val r = lsr(v)
                if (mode == M.ACC) a = r else bus.cpuWrite(addr, r)
            }
            I.ROL -> {
                val v = if (mode == M.ACC) a else bus.cpuRead(addr)
                val r = rol(v)
                if (mode == M.ACC) a = r else bus.cpuWrite(addr, r)
            }
            I.ROR -> {
                val v = if (mode == M.ACC) a else bus.cpuRead(addr)
                val r = ror(v)
                if (mode == M.ACC) a = r else bus.cpuWrite(addr, r)
            }
            I.SLO -> {
                val r = asl(bus.cpuRead(addr)); bus.cpuWrite(addr, r)
                a = a or r; zn(a)
            }
            I.RLA -> {
                val r = rol(bus.cpuRead(addr)); bus.cpuWrite(addr, r)
                a = a and r; zn(a)
            }
            I.SRE -> {
                val r = lsr(bus.cpuRead(addr)); bus.cpuWrite(addr, r)
                a = a xor r; zn(a)
            }
            I.RRA -> {
                val r = ror(bus.cpuRead(addr)); bus.cpuWrite(addr, r)
                adc(r)
            }
            I.DCP -> {
                val r = (bus.cpuRead(addr) - 1) and 0xFF
                bus.cpuWrite(addr, r); cmp(a, r)
            }
            I.ISB -> {
                val r = (bus.cpuRead(addr) + 1) and 0xFF
                bus.cpuWrite(addr, r); adc(r xor 0xFF)
            }
            I.BCC -> cyc += branch(!fc, addr)
            I.BCS -> cyc += branch(fc, addr)
            I.BEQ -> cyc += branch(fz, addr)
            I.BNE -> cyc += branch(!fz, addr)
            I.BMI -> cyc += branch(fn, addr)
            I.BPL -> cyc += branch(!fn, addr)
            I.BVC -> cyc += branch(!fv, addr)
            I.BVS -> cyc += branch(fv, addr)
            I.JMP -> pc = addr
            I.JSR -> {
                val ret = (pc - 1) and 0xFFFF
                push(ret shr 8); push(ret and 0xFF)
                pc = addr
            }
            I.RTS -> {
                val lo = pop()
                val hi = pop()
                pc = ((lo or (hi shl 8)) + 1) and 0xFFFF
            }
            I.RTI -> {
                setP(pop())
                val lo = pop()
                val hi = pop()
                pc = lo or (hi shl 8)
            }
            I.BRK -> {
                pc = (pc + 1) and 0xFFFF
                push(pc shr 8); push(pc and 0xFF)
                push(getP(true))
                fi = true
                pc = bus.cpuRead(0xFFFE) or (bus.cpuRead(0xFFFF) shl 8)
            }
            I.PHA -> push(a)
            I.PHP -> push(getP(true))
            I.PLA -> { a = pop(); zn(a) }
            I.PLP -> setP(pop())
            I.CLC -> fc = false
            I.SEC -> fc = true
            I.CLI -> fi = false
            I.SEI -> fi = true
            I.CLD -> fd = false
            I.SED -> fd = true
            I.CLV -> fv = false
            I.NOP -> {}
        }
        cycles += cyc
        return cyc
    }

    fun save(o: DataOutputStream) {
        o.writeInt(a); o.writeInt(x); o.writeInt(y); o.writeInt(sp); o.writeInt(pc)
        o.writeInt(getP(false))
        o.writeLong(cycles)
    }

    fun load(i: DataInputStream) {
        a = i.readInt(); x = i.readInt(); y = i.readInt(); sp = i.readInt(); pc = i.readInt()
        setP(i.readInt())
        cycles = i.readLong()
    }

    private fun interrupt(vector: Int): Int {
        push(pc shr 8); push(pc and 0xFF)
        push(getP(false))
        fi = true
        pc = bus.cpuRead(vector) or (bus.cpuRead(vector + 1) shl 8)
        cycles += 7
        return 7
    }

    private fun fetch(): Int {
        val b = bus.cpuRead(pc)
        pc = (pc + 1) and 0xFFFF
        return b
    }

    private fun push(v: Int) {
        bus.cpuWrite(0x100 or sp, v)
        sp = (sp - 1) and 0xFF
    }

    private fun pop(): Int {
        sp = (sp + 1) and 0xFF
        return bus.cpuRead(0x100 or sp)
    }

    private fun zn(v: Int) {
        fz = v == 0
        fn = (v and 0x80) != 0
    }

    private fun getP(brk: Boolean): Int =
        (if (fc) 1 else 0) or (if (fz) 2 else 0) or (if (fi) 4 else 0) or (if (fd) 8 else 0) or
            (if (brk) 0x10 else 0) or 0x20 or (if (fv) 0x40 else 0) or (if (fn) 0x80 else 0)

    private fun setP(p: Int) {
        fc = (p and 1) != 0
        fz = (p and 2) != 0
        fi = (p and 4) != 0
        fd = (p and 8) != 0
        fv = (p and 0x40) != 0
        fn = (p and 0x80) != 0
    }

    private fun adc(v: Int) {
        val sum = a + v + (if (fc) 1 else 0)
        fv = ((a xor sum) and (v xor sum) and 0x80) != 0
        fc = sum > 0xFF
        a = sum and 0xFF
        zn(a)
    }

    private fun cmp(r: Int, v: Int) {
        fc = r >= v
        zn((r - v) and 0xFF)
    }

    private fun asl(v: Int): Int {
        fc = (v and 0x80) != 0
        val r = (v shl 1) and 0xFF
        zn(r)
        return r
    }

    private fun lsr(v: Int): Int {
        fc = (v and 1) != 0
        val r = v shr 1
        zn(r)
        return r
    }

    private fun rol(v: Int): Int {
        val r = ((v shl 1) or (if (fc) 1 else 0)) and 0xFF
        fc = (v and 0x80) != 0
        zn(r)
        return r
    }

    private fun ror(v: Int): Int {
        val r = (v shr 1) or (if (fc) 0x80 else 0)
        fc = (v and 1) != 0
        zn(r)
        return r
    }

    private fun branch(cond: Boolean, target: Int): Int {
        if (!cond) return 0
        val extra = if ((pc and 0xFF00) != (target and 0xFF00)) 2 else 1
        pc = target
        return extra
    }

    private companion object {
        const val READ = 0
        const val STORE = 1
        const val RMW = 2

        val INST = Array(256) { I.NOP }
        val MODE = Array(256) { M.IMP }
        val CYC = IntArray(256) { 2 }
        val PEN = BooleanArray(256)
        val DEF = BooleanArray(256)

        private fun put(op: Int, i: I, m: M, kind: Int) {
            if (op < 0) return
            DEF[op] = true
            INST[op] = i
            MODE[op] = m
            CYC[op] = when (kind) {
                READ -> when (m) {
                    M.ZP -> 3
                    M.ZPX, M.ZPY, M.ABS, M.ABX, M.ABY -> 4
                    M.IZX -> 6
                    M.IZY -> 5
                    else -> 2
                }
                STORE -> when (m) {
                    M.ZP -> 3
                    M.ZPX, M.ZPY, M.ABS -> 4
                    M.ABX, M.ABY -> 5
                    else -> 6
                }
                else -> when (m) {
                    M.ZP -> 5
                    M.ZPX, M.ABS -> 6
                    M.ABX, M.ABY -> 7
                    else -> 8
                }
            }
            PEN[op] = kind == READ && (m == M.ABX || m == M.ABY || m == M.IZY)
        }

        private fun fam(
            i: I, kind: Int,
            imm: Int, zp: Int, zpx: Int, zpy: Int, abs: Int, abx: Int, aby: Int, izx: Int, izy: Int,
        ) {
            put(imm, i, M.IMM, kind)
            put(zp, i, M.ZP, kind)
            put(zpx, i, M.ZPX, kind)
            put(zpy, i, M.ZPY, kind)
            put(abs, i, M.ABS, kind)
            put(abx, i, M.ABX, kind)
            put(aby, i, M.ABY, kind)
            put(izx, i, M.IZX, kind)
            put(izy, i, M.IZY, kind)
        }

        private fun one(op: Int, i: I, m: M, cycles: Int) {
            DEF[op] = true
            INST[op] = i
            MODE[op] = m
            CYC[op] = cycles
            PEN[op] = false
        }

        init {
            // 讀取類
            fam(I.LDA, READ, 0xA9, 0xA5, 0xB5, -1, 0xAD, 0xBD, 0xB9, 0xA1, 0xB1)
            fam(I.LDX, READ, 0xA2, 0xA6, -1, 0xB6, 0xAE, -1, 0xBE, -1, -1)
            fam(I.LDY, READ, 0xA0, 0xA4, 0xB4, -1, 0xAC, 0xBC, -1, -1, -1)
            fam(I.AND, READ, 0x29, 0x25, 0x35, -1, 0x2D, 0x3D, 0x39, 0x21, 0x31)
            fam(I.ORA, READ, 0x09, 0x05, 0x15, -1, 0x0D, 0x1D, 0x19, 0x01, 0x11)
            fam(I.EOR, READ, 0x49, 0x45, 0x55, -1, 0x4D, 0x5D, 0x59, 0x41, 0x51)
            fam(I.ADC, READ, 0x69, 0x65, 0x75, -1, 0x6D, 0x7D, 0x79, 0x61, 0x71)
            fam(I.SBC, READ, 0xE9, 0xE5, 0xF5, -1, 0xED, 0xFD, 0xF9, 0xE1, 0xF1)
            fam(I.CMP, READ, 0xC9, 0xC5, 0xD5, -1, 0xCD, 0xDD, 0xD9, 0xC1, 0xD1)
            fam(I.CPX, READ, 0xE0, 0xE4, -1, -1, 0xEC, -1, -1, -1, -1)
            fam(I.CPY, READ, 0xC0, 0xC4, -1, -1, 0xCC, -1, -1, -1, -1)
            fam(I.BIT, READ, -1, 0x24, -1, -1, 0x2C, -1, -1, -1, -1)
            fam(I.LAX, READ, -1, 0xA7, -1, 0xB7, 0xAF, -1, 0xBF, 0xA3, 0xB3)
            put(0xEB, I.SBC, M.IMM, READ)
            // 寫入類
            fam(I.STA, STORE, -1, 0x85, 0x95, -1, 0x8D, 0x9D, 0x99, 0x81, 0x91)
            fam(I.STX, STORE, -1, 0x86, -1, 0x96, 0x8E, -1, -1, -1, -1)
            fam(I.STY, STORE, -1, 0x84, 0x94, -1, 0x8C, -1, -1, -1, -1)
            fam(I.SAX, STORE, -1, 0x87, -1, 0x97, 0x8F, -1, -1, 0x83, -1)
            // 讀改寫類
            fam(I.ASL, RMW, -1, 0x06, 0x16, -1, 0x0E, 0x1E, -1, -1, -1)
            fam(I.LSR, RMW, -1, 0x46, 0x56, -1, 0x4E, 0x5E, -1, -1, -1)
            fam(I.ROL, RMW, -1, 0x26, 0x36, -1, 0x2E, 0x3E, -1, -1, -1)
            fam(I.ROR, RMW, -1, 0x66, 0x76, -1, 0x6E, 0x7E, -1, -1, -1)
            fam(I.INC, RMW, -1, 0xE6, 0xF6, -1, 0xEE, 0xFE, -1, -1, -1)
            fam(I.DEC, RMW, -1, 0xC6, 0xD6, -1, 0xCE, 0xDE, -1, -1, -1)
            fam(I.DCP, RMW, -1, 0xC7, 0xD7, -1, 0xCF, 0xDF, 0xDB, 0xC3, 0xD3)
            fam(I.ISB, RMW, -1, 0xE7, 0xF7, -1, 0xEF, 0xFF, 0xFB, 0xE3, 0xF3)
            fam(I.SLO, RMW, -1, 0x07, 0x17, -1, 0x0F, 0x1F, 0x1B, 0x03, 0x13)
            fam(I.RLA, RMW, -1, 0x27, 0x37, -1, 0x2F, 0x3F, 0x3B, 0x23, 0x33)
            fam(I.SRE, RMW, -1, 0x47, 0x57, -1, 0x4F, 0x5F, 0x5B, 0x43, 0x53)
            fam(I.RRA, RMW, -1, 0x67, 0x77, -1, 0x6F, 0x7F, 0x7B, 0x63, 0x73)
            one(0x0A, I.ASL, M.ACC, 2)
            one(0x4A, I.LSR, M.ACC, 2)
            one(0x2A, I.ROL, M.ACC, 2)
            one(0x6A, I.ROR, M.ACC, 2)
            // 分支與流程控制
            one(0x10, I.BPL, M.REL, 2); one(0x30, I.BMI, M.REL, 2)
            one(0x50, I.BVC, M.REL, 2); one(0x70, I.BVS, M.REL, 2)
            one(0x90, I.BCC, M.REL, 2); one(0xB0, I.BCS, M.REL, 2)
            one(0xD0, I.BNE, M.REL, 2); one(0xF0, I.BEQ, M.REL, 2)
            one(0x00, I.BRK, M.IMP, 7)
            one(0x20, I.JSR, M.ABS, 6)
            one(0x40, I.RTI, M.IMP, 6)
            one(0x60, I.RTS, M.IMP, 6)
            one(0x4C, I.JMP, M.ABS, 3)
            one(0x6C, I.JMP, M.IND, 5)
            // 堆疊與旗標
            one(0x48, I.PHA, M.IMP, 3); one(0x08, I.PHP, M.IMP, 3)
            one(0x68, I.PLA, M.IMP, 4); one(0x28, I.PLP, M.IMP, 4)
            one(0x18, I.CLC, M.IMP, 2); one(0x38, I.SEC, M.IMP, 2)
            one(0x58, I.CLI, M.IMP, 2); one(0x78, I.SEI, M.IMP, 2)
            one(0xB8, I.CLV, M.IMP, 2); one(0xD8, I.CLD, M.IMP, 2)
            one(0xF8, I.SED, M.IMP, 2)
            // 暫存器搬移
            one(0xAA, I.TAX, M.IMP, 2); one(0xA8, I.TAY, M.IMP, 2)
            one(0xBA, I.TSX, M.IMP, 2); one(0x8A, I.TXA, M.IMP, 2)
            one(0x9A, I.TXS, M.IMP, 2); one(0x98, I.TYA, M.IMP, 2)
            one(0xE8, I.INX, M.IMP, 2); one(0xC8, I.INY, M.IMP, 2)
            one(0xCA, I.DEX, M.IMP, 2); one(0x88, I.DEY, M.IMP, 2)
            one(0xEA, I.NOP, M.IMP, 2)
            // 非官方 NOP
            for (op in intArrayOf(0x1A, 0x3A, 0x5A, 0x7A, 0xDA, 0xFA)) one(op, I.NOP, M.IMP, 2)
            for (op in intArrayOf(0x80, 0x82, 0x89, 0xC2, 0xE2)) one(op, I.NOP, M.IMM, 2)
            for (op in intArrayOf(0x04, 0x44, 0x64)) one(op, I.NOP, M.ZP, 3)
            for (op in intArrayOf(0x14, 0x34, 0x54, 0x74, 0xD4, 0xF4)) one(op, I.NOP, M.ZPX, 4)
            one(0x0C, I.NOP, M.ABS, 4)
            for (op in intArrayOf(0x1C, 0x3C, 0x5C, 0x7C, 0xDC, 0xFC)) {
                one(op, I.NOP, M.ABX, 4)
                PEN[op] = true
            }
        }
    }
}
