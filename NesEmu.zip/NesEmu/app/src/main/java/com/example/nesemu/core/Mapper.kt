package com.example.nesemu.core

import java.io.DataInputStream
import java.io.DataOutputStream

/** 卡帶 Mapper 基底類別：負責 CPU 的 $6000-$FFFF 與 PPU 的 $0000-$1FFF。 */
abstract class Mapper(protected val cart: Cartridge) {
    var mirror: Mirror = cart.mirror
    protected val prg: ByteArray = cart.prg
    protected val chr: ByteArray = cart.chr
    val prgRam = ByteArray(8192)

    open val irq: Boolean get() = false

    fun cpuRead(addr: Int): Int = when {
        addr >= 0x8000 -> prgRead(addr)
        addr >= 0x6000 -> prgRam[addr - 0x6000].toInt() and 0xFF
        else -> 0
    }

    /** 診斷：卡帶暫存器寫入次數。 */
    var regWrites = 0
        private set

    fun cpuWrite(addr: Int, v: Int) {
        if (addr >= 0x8000) {
            regWrites++
            regWrite(addr, v)
        } else if (addr >= 0x6000) {
            prgRam[addr - 0x6000] = v.toByte()
        }
    }

    protected abstract fun prgRead(addr: Int): Int
    protected abstract fun regWrite(addr: Int, v: Int)

    /** 把 PPU 位址 ($0000-$1FFF) 轉成 CHR 陣列內的位移。 */
    protected abstract fun chrOffset(addr: Int): Int

    fun ppuRead(addr: Int): Int = chr[chrOffset(addr) % chr.size].toInt() and 0xFF

    fun ppuWrite(addr: Int, v: Int) {
        if (cart.chrIsRam) chr[chrOffset(addr) % chr.size] = v.toByte()
    }

    /** 每條可見掃描線（PPU 週期 260）呼叫一次，MMC3 用來計數 IRQ。 */
    open fun scanline() {}

    /** Name table 位址 ($2000-$2FFF) 轉成 4KB VRAM 內的位移。 */
    fun ntIndex(addr: Int): Int {
        val table = (addr shr 10) and 3
        val page = when (mirror) {
            Mirror.HORIZONTAL -> table shr 1
            Mirror.VERTICAL -> table and 1
            Mirror.SINGLE0 -> 0
            Mirror.SINGLE1 -> 1
            Mirror.FOUR -> table
        }
        return page * 0x400 + (addr and 0x3FF)
    }

    protected fun prgByte(offset: Int): Int = prg[offset % prg.size].toInt() and 0xFF

    // ---- 即時存檔 ----
    fun save(o: DataOutputStream) {
        o.writeInt(mirror.ordinal)
        o.write(prgRam)
        if (cart.chrIsRam) o.write(chr)
        saveRegs(o)
    }

    fun load(i: DataInputStream) {
        mirror = Mirror.values()[i.readInt()]
        i.readFully(prgRam)
        if (cart.chrIsRam) i.readFully(chr)
        loadRegs(i)
    }

    protected open fun saveRegs(o: DataOutputStream) {}
    protected open fun loadRegs(i: DataInputStream) {}

    companion object {
        fun create(cart: Cartridge): Mapper = when (cart.mapperId) {
            0 -> Nrom(cart)
            1 -> Mmc1(cart)
            2 -> Uxrom(cart)
            3 -> Cnrom(cart)
            4 -> Mmc3(cart)
            7 -> Axrom(cart)
            66 -> Gxrom(cart)
            else -> throw RomException("尚未支援 Mapper ${cart.mapperId}")
        }
    }
}

/** Mapper 0 */
class Nrom(cart: Cartridge) : Mapper(cart) {
    override fun prgRead(addr: Int) = prgByte(addr - 0x8000)
    override fun regWrite(addr: Int, v: Int) {}
    override fun chrOffset(addr: Int) = addr
}

/** Mapper 1 (MMC1) */
class Mmc1(cart: Cartridge) : Mapper(cart) {
    private var shift = 0x10
    private var ctrl = 0x0C
    private var chr0 = 0
    private var chr1 = 0
    private var prgReg = 0

    init {
        updateMirror()
    }

    private fun updateMirror() {
        mirror = when (ctrl and 3) {
            0 -> Mirror.SINGLE0
            1 -> Mirror.SINGLE1
            2 -> Mirror.VERTICAL
            else -> Mirror.HORIZONTAL
        }
    }

    override fun saveRegs(o: DataOutputStream) {
        o.writeInt(shift); o.writeInt(ctrl); o.writeInt(chr0); o.writeInt(chr1); o.writeInt(prgReg)
    }

    override fun loadRegs(i: DataInputStream) {
        shift = i.readInt(); ctrl = i.readInt(); chr0 = i.readInt(); chr1 = i.readInt(); prgReg = i.readInt()
    }

    override fun regWrite(addr: Int, v: Int) {
        if ((v and 0x80) != 0) {
            shift = 0x10
            ctrl = ctrl or 0x0C
            updateMirror()
            return
        }
        val full = (shift and 1) != 0
        shift = (shift shr 1) or ((v and 1) shl 4)
        if (full) {
            when ((addr shr 13) and 3) {
                0 -> {
                    ctrl = shift
                    updateMirror()
                }
                1 -> chr0 = shift
                2 -> chr1 = shift
                else -> prgReg = shift
            }
            shift = 0x10
        }
    }

    override fun prgRead(addr: Int): Int {
        val banks16 = prg.size / 16384
        val offset = when ((ctrl shr 2) and 3) {
            0, 1 -> (prgReg and 0x0E) * 16384 + (addr - 0x8000)
            2 -> if (addr < 0xC000) addr - 0x8000
            else (prgReg and 0x0F) * 16384 + (addr - 0xC000)
            else -> if (addr < 0xC000) (prgReg and 0x0F) * 16384 + (addr - 0x8000)
            else (banks16 - 1) * 16384 + (addr - 0xC000)
        }
        return prgByte(offset)
    }

    override fun chrOffset(addr: Int): Int =
        if ((ctrl and 0x10) == 0) {
            (chr0 and 0x1E) * 4096 + addr
        } else if (addr < 0x1000) {
            chr0 * 4096 + addr
        } else {
            chr1 * 4096 + (addr - 0x1000)
        }
}

/** Mapper 2 (UxROM) */
class Uxrom(cart: Cartridge) : Mapper(cart) {
    private var bank = 0
    override fun regWrite(addr: Int, v: Int) {
        bank = v
    }

    override fun saveRegs(o: DataOutputStream) {
        o.writeInt(bank)
    }

    override fun loadRegs(i: DataInputStream) {
        bank = i.readInt()
    }

    override fun prgRead(addr: Int): Int =
        if (addr < 0xC000) prgByte(bank * 16384 + (addr - 0x8000))
        else prgByte(prg.size - 16384 + (addr - 0xC000))

    override fun chrOffset(addr: Int) = addr
}

/** Mapper 3 (CNROM) */
class Cnrom(cart: Cartridge) : Mapper(cart) {
    private var bank = 0
    override fun regWrite(addr: Int, v: Int) {
        bank = v
    }

    override fun saveRegs(o: DataOutputStream) {
        o.writeInt(bank)
    }

    override fun loadRegs(i: DataInputStream) {
        bank = i.readInt()
    }

    override fun prgRead(addr: Int) = prgByte(addr - 0x8000)
    override fun chrOffset(addr: Int) = bank * 8192 + addr
}

/** Mapper 7 (AxROM) */
class Axrom(cart: Cartridge) : Mapper(cart) {
    private var bank = 0

    init {
        mirror = Mirror.SINGLE0
    }

    override fun regWrite(addr: Int, v: Int) {
        bank = v and 7
        mirror = if ((v and 0x10) != 0) Mirror.SINGLE1 else Mirror.SINGLE0
    }

    override fun saveRegs(o: DataOutputStream) {
        o.writeInt(bank)
    }

    override fun loadRegs(i: DataInputStream) {
        bank = i.readInt()
    }

    override fun prgRead(addr: Int) = prgByte(bank * 32768 + (addr - 0x8000))
    override fun chrOffset(addr: Int) = addr
}

/** Mapper 66 (GxROM) */
class Gxrom(cart: Cartridge) : Mapper(cart) {
    private var prgBank = 0
    private var chrBank = 0
    override fun regWrite(addr: Int, v: Int) {
        prgBank = (v shr 4) and 3
        chrBank = v and 3
    }

    override fun saveRegs(o: DataOutputStream) {
        o.writeInt(prgBank); o.writeInt(chrBank)
    }

    override fun loadRegs(i: DataInputStream) {
        prgBank = i.readInt(); chrBank = i.readInt()
    }

    override fun prgRead(addr: Int) = prgByte(prgBank * 32768 + (addr - 0x8000))
    override fun chrOffset(addr: Int) = chrBank * 8192 + addr
}

/** Mapper 4 (MMC3) */
class Mmc3(cart: Cartridge) : Mapper(cart) {
    private val regs = IntArray(8)
    private var sel = 0
    private var prgMode = false
    private var chrMode = false
    private var latch = 0
    private var counter = 0
    private var reload = false
    private var enabled = false
    private var pending = false

    override val irq: Boolean get() = pending

    override fun saveRegs(o: DataOutputStream) {
        o.writeInts(regs)
        o.writeInt(sel)
        o.writeBoolean(prgMode); o.writeBoolean(chrMode)
        o.writeInt(latch); o.writeInt(counter)
        o.writeBoolean(reload); o.writeBoolean(enabled); o.writeBoolean(pending)
    }

    override fun loadRegs(i: DataInputStream) {
        i.readInts(regs)
        sel = i.readInt()
        prgMode = i.readBoolean(); chrMode = i.readBoolean()
        latch = i.readInt(); counter = i.readInt()
        reload = i.readBoolean(); enabled = i.readBoolean(); pending = i.readBoolean()
    }

    override fun regWrite(addr: Int, v: Int) {
        val even = (addr and 1) == 0
        when (addr and 0xE000) {
            0x8000 -> {
                if (even) {
                    sel = v and 7
                    prgMode = (v and 0x40) != 0
                    chrMode = (v and 0x80) != 0
                } else {
                    regs[sel] = v
                }
            }
            0xA000 -> {
                if (even && cart.mirror != Mirror.FOUR) {
                    mirror = if ((v and 1) != 0) Mirror.HORIZONTAL else Mirror.VERTICAL
                }
            }
            0xC000 -> {
                if (even) {
                    latch = v
                } else {
                    counter = 0
                    reload = true
                }
            }
            else -> {
                if (even) {
                    enabled = false
                    pending = false
                } else {
                    enabled = true
                }
            }
        }
    }

    override fun scanline() {
        if (counter == 0 || reload) {
            counter = latch
            reload = false
        } else {
            counter--
        }
        if (counter == 0 && enabled) pending = true
    }

    override fun prgRead(addr: Int): Int {
        val n8 = prg.size / 8192
        val bank = when ((addr shr 13) and 3) {
            0 -> if (prgMode) n8 - 2 else regs[6] and 0x3F
            1 -> regs[7] and 0x3F
            2 -> if (prgMode) regs[6] and 0x3F else n8 - 2
            else -> n8 - 1
        }
        return prg[(bank % n8) * 8192 + (addr and 0x1FFF)].toInt() and 0xFF
    }

    override fun chrOffset(addr: Int): Int {
        val slot = addr shr 10
        val b = if (!chrMode) {
            when (slot) {
                0 -> regs[0] and 0xFE
                1 -> regs[0] or 1
                2 -> regs[1] and 0xFE
                3 -> regs[1] or 1
                else -> regs[slot - 2]
            }
        } else {
            when (slot) {
                0, 1, 2, 3 -> regs[slot + 2]
                4 -> regs[0] and 0xFE
                5 -> regs[0] or 1
                6 -> regs[1] and 0xFE
                else -> regs[1] or 1
            }
        }
        return (b % (chr.size / 1024)) * 1024 + (addr and 0x3FF)
    }
}
