package com.example.nesemu.core

private val LENGTH_TABLE = intArrayOf(
    10, 254, 20, 2, 40, 4, 80, 6, 160, 8, 60, 10, 14, 12, 26, 14,
    12, 16, 24, 18, 48, 20, 96, 22, 192, 24, 72, 26, 16, 28, 32, 30,
)
private val DUTY_TABLE = arrayOf(
    intArrayOf(0, 1, 0, 0, 0, 0, 0, 0),
    intArrayOf(0, 1, 1, 0, 0, 0, 0, 0),
    intArrayOf(0, 1, 1, 1, 1, 0, 0, 0),
    intArrayOf(1, 0, 0, 1, 1, 1, 1, 1),
)
private val NOISE_TABLE = intArrayOf(
    4, 8, 16, 32, 64, 96, 128, 160, 202, 254, 380, 508, 762, 1016, 2034, 4068,
)
private val DMC_RATE_TABLE = intArrayOf(
    428, 380, 340, 320, 286, 254, 226, 214, 190, 160, 142, 128, 106, 84, 72, 54,
)
private val PULSE_TBL = DoubleArray(31) { if (it == 0) 0.0 else 95.52 / (8128.0 / it + 100.0) }
private val TND_TBL = DoubleArray(203) { if (it == 0) 0.0 else 163.67 / (24329.0 / it + 100.0) }

private const val SAMPLE_RATE = 44100
private const val CPU_HZ = 1789773.0
private const val CYCLES_PER_SAMPLE = CPU_HZ / SAMPLE_RATE

private class Envelope {
    var halt = false
    var constVol = false
    var vol = 0
    var start = false
    private var div = 0
    private var decay = 0

    fun write(v: Int) {
        halt = (v and 0x20) != 0
        constVol = (v and 0x10) != 0
        vol = v and 0x0F
    }

    fun clock() {
        if (start) {
            start = false
            decay = 15
            div = vol
        } else if (div == 0) {
            div = vol
            if (decay > 0) decay-- else if (halt) decay = 15
        } else {
            div--
        }
    }

    fun out(): Int = if (constVol) vol else decay
}

private class Pulse(private val onesComplement: Boolean) {
    var enabled = false
    val env = Envelope()
    var len = 0
    private var duty = 0
    private var seq = 0
    private var period = 0
    private var timer = 0
    private var swEnable = false
    private var swPeriod = 0
    private var swNegate = false
    private var swShift = 0
    private var swReload = false
    private var swDiv = 0

    fun writeCtrl(v: Int) {
        duty = v shr 6
        env.write(v)
    }

    fun writeSweep(v: Int) {
        swEnable = (v and 0x80) != 0
        swPeriod = (v shr 4) and 7
        swNegate = (v and 8) != 0
        swShift = v and 7
        swReload = true
    }

    fun writeLo(v: Int) {
        period = (period and 0x700) or v
    }

    fun writeHi(v: Int) {
        period = (period and 0xFF) or ((v and 7) shl 8)
        if (enabled) len = LENGTH_TABLE[v shr 3]
        seq = 0
        env.start = true
    }

    fun clockTimer() {
        if (timer == 0) {
            timer = period
            seq = (seq + 1) and 7
        } else {
            timer--
        }
    }

    fun clockLen() {
        if (!env.halt && len > 0) len--
    }

    private fun target(): Int {
        val d = period shr swShift
        return if (swNegate) period - d - (if (onesComplement) 1 else 0) else period + d
    }

    fun clockSweep() {
        val tg = target()
        if (swDiv == 0 && swEnable && swShift > 0 && period >= 8 && tg <= 0x7FF) period = tg
        if (swDiv == 0 || swReload) {
            swDiv = swPeriod
            swReload = false
        } else {
            swDiv--
        }
    }

    fun output(): Int {
        if (!enabled || len == 0 || DUTY_TABLE[duty][seq] == 0 || period < 8 || target() > 0x7FF) return 0
        return env.out()
    }
}

private class Triangle {
    var enabled = false
    var control = false
    var linearReload = 0
    var reloadFlag = false
    var period = 0
    var len = 0
    private var linear = 0
    private var timer = 0
    private var seq = 0

    fun clockTimer() {
        if (timer == 0) {
            timer = period
            if (len > 0 && linear > 0) seq = (seq + 1) and 31
        } else {
            timer--
        }
    }

    fun clockLinear() {
        if (reloadFlag) linear = linearReload else if (linear > 0) linear--
        if (!control) reloadFlag = false
    }

    fun clockLen() {
        if (!control && len > 0) len--
    }

    fun output(): Int {
        if (period < 2) return 7
        return if (seq < 16) 15 - seq else seq - 16
    }
}

private class Noise {
    var enabled = false
    val env = Envelope()
    var mode = false
    var period = 4
    var len = 0
    private var timer = 0
    private var shift = 1

    fun clockTimer() {
        if (timer == 0) {
            timer = period - 1
            val bit = if (mode) 6 else 1
            val fb = (shift xor (shift shr bit)) and 1
            shift = (shift shr 1) or (fb shl 14)
        } else {
            timer--
        }
    }

    fun clockLen() {
        if (!env.halt && len > 0) len--
    }

    fun output(): Int = if (!enabled || len == 0 || (shift and 1) != 0) 0 else env.out()
}

/** APU：2 個方波、三角波、噪音、DMC。每個 CPU 週期呼叫一次 step()。 */
class Apu(private val bus: Bus) {
    private val p1 = Pulse(true)
    private val p2 = Pulse(false)
    private val tri = Triangle()
    private val noise = Noise()

    private var frameCycle = 0
    private var fiveStep = false
    private var irqInhibit = false
    private var frameIrq = false
    private var oddCycle = false

    // DMC
    private var dmcIrqEnable = false
    private var dmcLoop = false
    private var dmcRate = 428
    private var dmcTimer = 0
    private var dmcLevel = 0
    private var dmcAddrReg = 0xC000
    private var dmcLenReg = 1
    private var dmcAddr = 0
    private var dmcBytes = 0
    private var dmcBuf = 0
    private var dmcBufEmpty = true
    private var dmcShift = 0
    private var dmcBits = 8
    private var dmcSilence = true
    private var dmcIrq = false

    val irq: Boolean get() = frameIrq || dmcIrq

    // 音訊輸出（44.1kHz 單聲道 16-bit）
    val samples = ShortArray(8192)
    var sampleCount = 0
    private var accum = 0.0
    private var accCount = 0
    private var sampleTimer = 0.0
    private var prevX = 0.0
    private var prevY = 0.0

    fun write(addr: Int, v: Int) {
        when (addr) {
            0x4000 -> p1.writeCtrl(v)
            0x4001 -> p1.writeSweep(v)
            0x4002 -> p1.writeLo(v)
            0x4003 -> p1.writeHi(v)
            0x4004 -> p2.writeCtrl(v)
            0x4005 -> p2.writeSweep(v)
            0x4006 -> p2.writeLo(v)
            0x4007 -> p2.writeHi(v)
            0x4008 -> {
                tri.control = (v and 0x80) != 0
                tri.linearReload = v and 0x7F
            }
            0x400A -> tri.period = (tri.period and 0x700) or v
            0x400B -> {
                tri.period = (tri.period and 0xFF) or ((v and 7) shl 8)
                if (tri.enabled) tri.len = LENGTH_TABLE[v shr 3]
                tri.reloadFlag = true
            }
            0x400C -> noise.env.write(v)
            0x400E -> {
                noise.mode = (v and 0x80) != 0
                noise.period = NOISE_TABLE[v and 0x0F]
            }
            0x400F -> {
                if (noise.enabled) noise.len = LENGTH_TABLE[v shr 3]
                noise.env.start = true
            }
            0x4010 -> {
                dmcIrqEnable = (v and 0x80) != 0
                dmcLoop = (v and 0x40) != 0
                dmcRate = DMC_RATE_TABLE[v and 0x0F]
                if (!dmcIrqEnable) dmcIrq = false
            }
            0x4011 -> dmcLevel = v and 0x7F
            0x4012 -> dmcAddrReg = 0xC000 or (v shl 6)
            0x4013 -> dmcLenReg = (v shl 4) or 1
            0x4015 -> {
                p1.enabled = (v and 1) != 0
                if (!p1.enabled) p1.len = 0
                p2.enabled = (v and 2) != 0
                if (!p2.enabled) p2.len = 0
                tri.enabled = (v and 4) != 0
                if (!tri.enabled) tri.len = 0
                noise.enabled = (v and 8) != 0
                if (!noise.enabled) noise.len = 0
                dmcIrq = false
                if ((v and 0x10) != 0) {
                    if (dmcBytes == 0) dmcRestart()
                    dmcFill()
                } else {
                    dmcBytes = 0
                }
            }
            0x4017 -> {
                fiveStep = (v and 0x80) != 0
                irqInhibit = (v and 0x40) != 0
                if (irqInhibit) frameIrq = false
                frameCycle = 0
                if (fiveStep) {
                    quarter()
                    half()
                }
            }
        }
    }

    fun readStatus(): Int {
        var s = 0
        if (p1.len > 0) s = s or 0x01
        if (p2.len > 0) s = s or 0x02
        if (tri.len > 0) s = s or 0x04
        if (noise.len > 0) s = s or 0x08
        if (dmcBytes > 0) s = s or 0x10
        if (frameIrq) s = s or 0x40
        if (dmcIrq) s = s or 0x80
        frameIrq = false
        return s
    }

    private fun quarter() {
        p1.env.clock()
        p2.env.clock()
        noise.env.clock()
        tri.clockLinear()
    }

    private fun half() {
        p1.clockLen(); p2.clockLen(); tri.clockLen(); noise.clockLen()
        p1.clockSweep(); p2.clockSweep()
    }

    private fun dmcRestart() {
        dmcAddr = dmcAddrReg
        dmcBytes = dmcLenReg
    }

    private fun dmcFill() {
        if (dmcBufEmpty && dmcBytes > 0) {
            dmcBuf = bus.cpuRead(dmcAddr)
            dmcAddr = if (dmcAddr == 0xFFFF) 0x8000 else dmcAddr + 1
            dmcBytes--
            dmcBufEmpty = false
            if (dmcBytes == 0) {
                if (dmcLoop) dmcRestart() else if (dmcIrqEnable) dmcIrq = true
            }
        }
    }

    private fun dmcClock() {
        if (dmcTimer > 0) {
            dmcTimer--
            return
        }
        dmcTimer = dmcRate - 1
        if (!dmcSilence) {
            if ((dmcShift and 1) != 0) {
                if (dmcLevel <= 125) dmcLevel += 2
            } else {
                if (dmcLevel >= 2) dmcLevel -= 2
            }
            dmcShift = dmcShift shr 1
        }
        dmcBits--
        if (dmcBits == 0) {
            dmcBits = 8
            if (dmcBufEmpty) {
                dmcSilence = true
            } else {
                dmcSilence = false
                dmcShift = dmcBuf
                dmcBufEmpty = true
                dmcFill()
            }
        }
    }

    fun step() {
        frameCycle++
        when (frameCycle) {
            7457 -> quarter()
            14913 -> {
                quarter()
                half()
            }
            22371 -> quarter()
            29829 -> if (!fiveStep) {
                quarter()
                half()
                if (!irqInhibit) frameIrq = true
            }
            37281 -> if (fiveStep) {
                quarter()
                half()
            }
        }
        if (frameCycle >= (if (fiveStep) 37282 else 29830)) frameCycle = 0

        tri.clockTimer()
        noise.clockTimer()
        dmcClock()
        oddCycle = !oddCycle
        if (oddCycle) {
            p1.clockTimer()
            p2.clockTimer()
        }

        val pulse = p1.output() + p2.output()
        val tnd = 3 * tri.output() + 2 * noise.output() + dmcLevel
        accum += PULSE_TBL[pulse] + TND_TBL[tnd]
        accCount++
        sampleTimer += 1.0
        if (sampleTimer >= CYCLES_PER_SAMPLE) {
            sampleTimer -= CYCLES_PER_SAMPLE
            val x = accum / accCount
            accum = 0.0
            accCount = 0
            // 高通濾波去除直流偏移
            val y = x - prevX + 0.995 * prevY
            prevX = x
            prevY = y
            if (sampleCount < samples.size) {
                samples[sampleCount++] = (y * 40000.0).toInt().coerceIn(-32768, 32767).toShort()
            }
        }
    }
}
