package com.example.nesemu.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.SurfaceHolder
import android.view.SurfaceView

/** 顯示遊戲畫面的 SurfaceView。由模擬執行緒呼叫 drawFrame()。 */
class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {
    @Volatile
    private var surfaceValid = false
    private val src = Rect(0, 0, 256, 240)
    private val dst = Rect()
    private val paint = Paint().apply { isFilterBitmap = false }

    init {
        holder.addCallback(this)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        surfaceValid = true
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        surfaceValid = false
    }

    fun drawFrame(bitmap: Bitmap) {
        if (!surfaceValid) return
        val canvas = holder.lockCanvas() ?: return
        try {
            canvas.drawColor(Color.BLACK)
            val r = gameRect(canvas.width, canvas.height)
            dst.set(r.left.toInt(), r.top.toInt(), r.right.toInt(), r.bottom.toInt())
            canvas.drawBitmap(bitmap, src, dst, paint)
        } finally {
            holder.unlockCanvasAndPost(canvas)
        }
    }

    companion object {
        /** 畫面寬高比；可在選單中切換（4:3、原始像素比例、16:9）。 */
        @Volatile
        var aspect = 4f / 3f

        fun aspectFor(mode: Int): Float = when (mode) {
            1 -> 256f / 240f
            2 -> 16f / 9f
            else -> 4f / 3f
        }

        /** 計算遊戲畫面在 w x h 螢幕上的位置；直向靠上、橫向置中。 */
        fun gameRect(w: Int, h: Int): RectF {
            val a = aspect
            return if (w >= h) {
                val gw = minOf(h * a, w.toFloat())
                val left = (w - gw) / 2f
                RectF(left, 0f, left + gw, h.toFloat())
            } else {
                val top = h * 0.04f
                RectF(0f, top, w.toFloat(), top + w / a)
            }
        }
    }
}
