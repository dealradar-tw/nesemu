package com.example.nesemu.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.SurfaceHolder
import android.view.SurfaceView

/** 顯示遊戲畫面的 SurfaceView。由模擬執行緒呼叫 drawFrame()。 */
class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {
    @Volatile
    private var surfaceValid = false
    private val src = Rect(0, 0, 256, 240)
    private val dst = Rect()
    private val paint = Paint().apply { isFilterBitmap = false }

    init {
        holder.addCallback(this)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        surfaceValid = true
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        surfaceValid = false
    }

    fun drawFrame(bitmap: Bitmap) {
        if (!surfaceValid) return
        val canvas = holder.lockCanvas() ?: return
        try {
            canvas.drawColor(Color.BLACK)
            val r = gameRect(canvas.width, canvas.height)
            dst.set(r.left.toInt(), r.top.toInt(), r.right.toInt(), r.bottom.toInt())
            canvas.drawBitmap(bitmap, src, dst, paint)
        } finally {
            holder.unlockCanvasAndPost(canvas)
        }
    }

    companion object {
        /** 畫面顯示比例（NES 在電視上為 4:3）。 */
        const val ASPECT = 4f / 3f

        /** 計算遊戲畫面在 w x h 螢幕上的位置；直向靠上、橫向置中。 */
        fun gameRect(w: Int, h: Int): RectF {
            return if (w >= h) {
                val gw = h * ASPECT
                val left = (w - gw) / 2f
                RectF(left, 0f, left + gw, h.toFloat())
            } else {
                val top = h * 0.04f
                RectF(0f, top, w.toFloat(), top + w / ASPECT)
            }
        }
    }
}
