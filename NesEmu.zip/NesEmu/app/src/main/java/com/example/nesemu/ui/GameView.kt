package com.example.nesemu.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.SurfaceHolder
import android.view.SurfaceView

/** 顯示遊戲畫面的 SurfaceView。由模擬執行緒呼叫 drawFrame()。 */
class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {
    @Volatile
    private var surfaceValid = false
    private val srcFull = Rect(0, 0, 256, 240)
    private val srcCrop = Rect(0, 8, 256, 232)
    private val dst = Rect()
    private val dstF = RectF()
    private val paint = Paint().apply { isFilterBitmap = false }

    init {
        holder.addCallback(this)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        surfaceValid = true
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        surfaceValid = false
    }

    fun drawFrame(bitmap: Bitmap) {
        if (!surfaceValid) return
        val canvas = holder.lockCanvas() ?: return
        try {
            canvas.drawColor(Color.BLACK)
            val r = gameRect(canvas.width, canvas.height)
            dst.set(r.left.toInt(), r.top.toInt(), r.right.toInt(), r.bottom.toInt())
            val base = if (cropOverscan) srcCrop else srcFull
            if (zoom <= 1.001f) {
                canvas.drawBitmap(bitmap, base, dst, paint)
            } else {
                val bw = base.width().toFloat()
                val bh = base.height().toFloat()
                val vw = bw / zoom
                val vh = bh / zoom
                viewLeft = viewLeft.coerceIn(0f, bw - vw)
                viewTop = viewTop.coerceIn(0f, bh - vh)
                val k = r.width() / vw
                val dl = r.left - viewLeft * k
                val dt = r.top - viewTop * k
                dstF.set(dl, dt, dl + bw * k, dt + bh * k)
                canvas.save()
                canvas.clipRect(r)
                canvas.drawBitmap(bitmap, base, dstF, paint)
                canvas.restore()
            }
        } finally {
            holder.unlockCanvasAndPost(canvas)
        }
    }

    companion object {
        /** 兩指縮放：倍率（1 = 不放大）與目前顯示範圍左上角（以畫面像素為單位）。 */
        @Volatile
        var zoom = 1f
        @Volatile
        var viewLeft = 0f
        @Volatile
        var viewTop = 0f
        const val MAX_ZOOM = 4f

        fun resetZoom() {
            zoom = 1f; viewLeft = 0f; viewTop = 0f
        }

        /**
         * 兩指縮放/拖曳。factor 為這次的縮放比例，(fx, fy) 為兩指中心（螢幕座標），
         * (dx, dy) 為中心移動量；讓兩指中心下方的畫面點跟著手指走。
         */
        fun pinch(w: Int, h: Int, factor: Float, fx: Float, fy: Float, dx: Float, dy: Float) {
            val r = gameRect(w, h)
            val base = if (cropOverscan) Rect(0, 8, 256, 232) else Rect(0, 0, 256, 240)
            val bw = base.width().toFloat()
            val bh = base.height().toFloat()
            val z0 = zoom
            val z1 = (z0 * factor).coerceIn(1f, MAX_ZOOM)
            val vw0 = bw / z0
            val sx = viewLeft + (fx - r.left) / r.width() * vw0
            val sy = viewTop + (fy - r.top) / r.height() * (bh / z0)
            val vw1 = bw / z1
            val vh1 = bh / z1
            val u = (fx + dx - r.left) / r.width()
            val v = (fy + dy - r.top) / r.height()
            zoom = if (z1 < 1.05f) 1f else z1
            if (zoom == 1f) {
                viewLeft = 0f; viewTop = 0f
            } else {
                viewLeft = (sx - u * vw1).coerceIn(0f, bw - vw1)
                viewTop = (sy - v * vh1).coerceIn(0f, bh - vh1)
            }
        }

        /** 裁掉上下各 8 行（電視本來就看不到的邊緣，捲動時常有未更新的破圖）。 */
        @Volatile
        var cropOverscan = true

        /** 畫面寬高比；可在選單中切換（4:3、原始像素比例、16:9）。 */
        @Volatile
        var aspect = 4f / 3f

        fun aspectFor(mode: Int): Float = when (mode) {
            1 -> if (cropOverscan) 256f / 224f else 256f / 240f
            2 -> 16f / 9f
            else -> 4f / 3f
        }

        /** 計算遊戲畫面在 w x h 螢幕上的位置；直向靠上、橫向置中。 */
        fun gameRect(w: Int, h: Int): RectF {
            val a = aspect
            return if (w >= h) {
                val gw = minOf(h * a, w.toFloat())
                val left = (w - gw) / 2f
                RectF(left, 0f, left + gw, h.toFloat())
            } else {
                val top = h * 0.04f
                RectF(0f, top, w.toFloat(), top + w / a)
            }
        }
    }
}
