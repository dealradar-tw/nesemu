package com.example.nesemu.ui

import android.content.Context
import java.io.File

/** 使用者設定（存在 SharedPreferences），模擬執行緒與介面共用。 */
class Settings(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    /** 連發週期（幀）：2=30 次/秒、3=20、4=15、6=10。 */
    @Volatile
    var turboPeriod: Int = prefs.getInt("turbo", 4)
        set(v) {
            field = v
            prefs.edit().putInt("turbo", v).apply()
        }

    /** 快轉倍率（2～4）。 */
    @Volatile
    var ffMultiplier: Int = prefs.getInt("ff", 2)
        set(v) {
            field = v
            prefs.edit().putInt("ff", v).apply()
        }

    /** 畫面方向：0=自動、1=直向、2=橫向。 */
    var orientationMode: Int = prefs.getInt("orientation", 0)
        set(v) {
            field = v
            prefs.edit().putInt("orientation", v).apply()
        }

    /** 畫面比例：0=4:3、1=原始像素比例、2=16:9。 */
    var aspectMode: Int = prefs.getInt("aspect", 0)
        set(v) {
            field = v
            prefs.edit().putInt("aspect", v).apply()
        }

    /** 加長垂直空白：0=自動、1=關、2=開（加 50 行）。 */
    var vblankMode: Int = prefs.getInt("vblank", 0)
        set(v) {
            field = v
            prefs.edit().putInt("vblank", v).apply()
        }

    /** 防閃爍：渲染不完整的畫面沿用上一幀（預設開啟）。 */
    var antiFlicker: Boolean = prefs.getBoolean("antiflicker", true)
        set(v) {
            field = v
            prefs.edit().putBoolean("antiflicker", v).apply()
        }

    /** 是否裁掉畫面上下各 8 行（預設開啟）。 */
    var cropOverscan: Boolean = prefs.getBoolean("crop", true)
        set(v) {
            field = v
            prefs.edit().putBoolean("crop", v).apply()
        }

    /** 快速存讀檔使用的欄位（1～4）。 */
    var slot: Int = prefs.getInt("slot", 1)
        set(v) {
            field = v
            prefs.edit().putInt("slot", v).apply()
        }

    /** 目前是否快轉中（不保存）。 */
    @Volatile
    var fastForward = false
}

/** 單一金手指項目。 */
class CheatEntry(val code: String, val name: String, var enabled: Boolean)

/** 依遊戲（ROM 的 CRC32）保存金手指清單。 */
object CheatStore {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("cheats", Context.MODE_PRIVATE)

    fun load(ctx: Context, crc: Long): MutableList<CheatEntry> {
        val raw = prefs(ctx).getString("%08x".format(crc), "") ?: ""
        val out = mutableListOf<CheatEntry>()
        for (line in raw.split('\n')) {
            val p = line.split('\t', limit = 3)
            if (p.size == 3) out.add(CheatEntry(p[1], p[2], p[0] == "1"))
        }
        return out
    }

    fun save(ctx: Context, crc: Long, list: List<CheatEntry>) {
        val raw = list.joinToString("\n") {
            (if (it.enabled) "1" else "0") + "\t" + it.code + "\t" + it.name.replace('\t', ' ').replace('\n', ' ')
        }
        prefs(ctx).edit().putString("%08x".format(crc), raw).apply()
    }
}

/** 即時存檔檔案位置：files/states/<CRC>_<欄位>.sav */
object StateStore {
    fun file(ctx: Context, crc: Long, slot: Int): File {
        val dir = File(ctx.filesDir, "states")
        dir.mkdirs()
        return File(dir, "%08x_%d.sav".format(crc, slot))
    }

    /** 存檔當下的畫面縮圖（讀檔時顯示，方便辨認進度）。 */
    fun thumb(ctx: Context, crc: Long, slot: Int): File {
        val dir = File(ctx.filesDir, "states")
        dir.mkdirs()
        return File(dir, "%08x_%d.png".format(crc, slot))
    }

    const val SLOT_COUNT = 6
}
