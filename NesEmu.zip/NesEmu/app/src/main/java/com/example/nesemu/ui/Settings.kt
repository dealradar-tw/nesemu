package com.example.nesemu.ui

import android.content.Context
import java.io.File

/** 使用者設定（存在 SharedPreferences），模擬執行緒與介面共用。 */
class Settings(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    /** 連發週期（幀）：2=30 次/秒、3=20、4=15、6=10。 */
    @Volatile
    var turboPeriod: Int = prefs.getInt("turbo", 4)
        set(v) {
            field = v
            prefs.edit().putInt("turbo", v).apply()
        }

    /** 快轉倍率（2～4）。 */
    @Volatile
    var ffMultiplier: Int = prefs.getInt("ff", 2)
        set(v) {
            field = v
            prefs.edit().putInt("ff", v).apply()
        }

    /** 畫面方向：0=自動、1=直向、2=橫向。 */
    var orientationMode: Int = prefs.getInt("orientation", 0)
        set(v) {
            field = v
            prefs.edit().putInt("orientation", v).apply()
        }

    /** 畫面比例：0=4:3、1=原始像素比例、2=16:9。 */
    var aspectMode: Int = prefs.getInt("aspect", 0)
        set(v) {
            field = v
            prefs.edit().putInt("aspect", v).apply()
        }

    /** 加長垂直空白：0=自動、1=關、2=開（加 50 行）。 */
    var vblankMode: Int = prefs.getInt("vblank", 0)
        set(v) {
            field = v
            prefs.edit().putInt("vblank", v).apply()
        }

    /** 防閃爍：渲染不完整的畫面沿用上一幀（預設開啟）。 */
    var antiFlicker: Boolean = prefs.getBoolean("antiflicker", true)
        set(v) {
            field = v
            prefs.edit().putBoolean("antiflicker", v).apply()
        }

    /** 是否裁掉畫面上下各 8 行（預設開啟）。 */
    var cropOverscan: Boolean = prefs.getBoolean("crop", true)
        set(v) {
            field = v
            prefs.edit().putBoolean("crop", v).apply()
        }

    /** 快速存讀檔使用的欄位（1～4）。 */
    var slot: Int = prefs.getInt("slot", 1)
        set(v) {
            field = v
            prefs.edit().putInt("slot", v).apply()
        }

    /** 虛擬按鍵大小（百分比）：85、100、115、125。 */
    var btnScale: Int = prefs.getInt("btnScale", 100)
        set(v) {
            field = v
            prefs.edit().putInt("btnScale", v).apply()
        }

    /** 虛擬按鍵不透明度（百分比）：50＝淡、100＝標準、160＝明顯。 */
    var btnAlpha: Int = prefs.getInt("btnAlpha", 100)
        set(v) {
            field = v
            prefs.edit().putInt("btnAlpha", v).apply()
        }

    /** 按鍵震動回饋。 */
    var haptics: Boolean = prefs.getBoolean("haptics", true)
        set(v) {
            field = v
            prefs.edit().putBoolean("haptics", v).apply()
        }

    /** 離開遊戲或切到背景時自動存檔（欄位 0），下次開啟可接續。 */
    var autoSave: Boolean = prefs.getBoolean("autoSave", true)
        set(v) {
            field = v
            prefs.edit().putBoolean("autoSave", v).apply()
        }

    /**
     * 實體手把自訂按鍵：Android 按鍵碼 → 功能。
     * 功能值為正數時是 Pad 位元；負數時是功能鍵（-ControlsView.ACTION_xxx）。
     */
    var keyMap: Map<Int, Int> = parseKeyMap(prefs.getString("keyMap", "") ?: "")
        set(v) {
            field = v
            prefs.edit().putString("keyMap", v.entries.joinToString(",") { "${it.key}:${it.value}" }).apply()
        }

    private fun parseKeyMap(raw: String): Map<Int, Int> {
        val m = LinkedHashMap<Int, Int>()
        for (part in raw.split(',')) {
            val kv = part.split(':')
            if (kv.size == 2) {
                val k = kv[0].toIntOrNull()
                val v = kv[1].toIntOrNull()
                if (k != null && v != null) m[k] = v
            }
        }
        return m
    }

    /** 首頁「ROM 資料夾」的樹狀 URI（null 表示未設定）。 */
    var romFolder: String? = prefs.getString("romFolder", null)
        set(v) {
            field = v
            prefs.edit().putString("romFolder", v).apply()
        }

    /** 目前是否快轉中（不保存）。 */
    @Volatile
    var fastForward = false
}

/** 單一金手指項目。 */
class CheatEntry(val code: String, val name: String, var enabled: Boolean)

/** 依遊戲（ROM 的 CRC32）保存金手指清單。 */
object CheatStore {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("cheats", Context.MODE_PRIVATE)

    fun load(ctx: Context, crc: Long): MutableList<CheatEntry> {
        val raw = prefs(ctx).getString("%08x".format(crc), "") ?: ""
        val out = mutableListOf<CheatEntry>()
        for (line in raw.split('\n')) {
            val p = line.split('\t', limit = 3)
            if (p.size == 3) out.add(CheatEntry(p[1], p[2], p[0] == "1"))
        }
        return out
    }

    fun save(ctx: Context, crc: Long, list: List<CheatEntry>) {
        val raw = list.joinToString("\n") {
            (if (it.enabled) "1" else "0") + "\t" + it.code + "\t" + it.name.replace('\t', ' ').replace('\n', ' ')
        }
        prefs(ctx).edit().putString("%08x".format(crc), raw).apply()
    }
}

/** 即時存檔檔案位置：files/states/<CRC>_<欄位>.sav */
object StateStore {
    fun file(ctx: Context, crc: Long, slot: Int): File {
        val dir = File(ctx.filesDir, "states")
        dir.mkdirs()
        return File(dir, "%08x_%d.sav".format(crc, slot))
    }

    /** 存檔當下的畫面縮圖（讀檔時顯示，方便辨認進度）。 */
    fun thumb(ctx: Context, crc: Long, slot: Int): File {
        val dir = File(ctx.filesDir, "states")
        dir.mkdirs()
        return File(dir, "%08x_%d.png".format(crc, slot))
    }

    const val SLOT_COUNT = 6

    /** 自動存檔使用的欄位編號。 */
    const val AUTO_SLOT = 0

    /** 刪除某遊戲的所有即時存檔與縮圖（電池存檔不動）。 */
    fun deleteAll(ctx: Context, crc: Long) {
        for (i in 0..SLOT_COUNT) {
            file(ctx, crc, i).delete()
            thumb(ctx, crc, i).delete()
        }
    }
}

/** 記錄「ROM 位址 → CRC」，讓首頁能找到該遊戲的自動存檔縮圖。 */
object RomIndex {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("romcrc", Context.MODE_PRIVATE)

    fun put(ctx: Context, uri: String, crc: Long) {
        prefs(ctx).edit().putLong(uri, crc).apply()
    }

    fun get(ctx: Context, uri: String): Long? {
        val p = prefs(ctx)
        return if (p.contains(uri)) p.getLong(uri, 0L) else null
    }

    fun remove(ctx: Context, uri: String) {
        prefs(ctx).edit().remove(uri).apply()
    }
}

/** 最近遊玩清單（每行：uri \t 名稱），首頁與遊戲畫面共用。 */
object RecentStore {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("recent", Context.MODE_PRIVATE)

    fun load(ctx: Context): List<Pair<String, String>> {
        val raw = prefs(ctx).getString("list", "") ?: ""
        return raw.split('\n').filter { it.contains('\t') }.map {
            val p = it.split('\t', limit = 2)
            p[0] to p[1]
        }
    }

    private fun store(ctx: Context, list: List<Pair<String, String>>) {
        val raw = list.joinToString("\n") { it.first + "\t" + it.second }
        prefs(ctx).edit().putString("list", raw).apply()
    }

    fun add(ctx: Context, uri: String, name: String) {
        val list = load(ctx).filter { it.first != uri }.toMutableList()
        list.add(0, uri to name.replace('\n', ' ').replace('\t', ' '))
        store(ctx, list.take(12))
    }

    fun remove(ctx: Context, uri: String) {
        store(ctx, load(ctx).filter { it.first != uri })
    }
}
