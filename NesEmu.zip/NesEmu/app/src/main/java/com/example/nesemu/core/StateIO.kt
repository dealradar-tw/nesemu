package com.example.nesemu.core

import java.io.DataInputStream
import java.io.DataOutputStream

internal fun DataOutputStream.writeInts(a: IntArray) {
    for (v in a) writeInt(v)
}

internal fun DataInputStream.readInts(a: IntArray) {
    for (i in a.indices) a[i] = readInt()
}
