package com.example.nesemu.core

import java.io.DataInputStream
import java.io.DataOutputStream

/** 手把按鍵位元。 */
object Pad {
    const val A = 0x01
    const val B = 0x02
    const val SELECT = 0x04
    const val START = 0x08
    const val UP = 0x10
    const val DOWN = 0x20
    const val LEFT = 0x40
    const val RIGHT = 0x80

    /** 介面專用位元：連發 A / 連發 B（不會直接送進模擬器）。 */
    const val TURBO_A = 0x100
    const val TURBO_B = 0x200

    /** 倒轉鍵（不送進模擬器，由執行緒處理）。 */
    const val REWIND = 0x400
}

/** CPU 位址匯流排：RAM、PPU/APU 暫存器、手把與卡帶。 */
class Bus(val mapper: Mapper) {
    private val ram = IntArray(2048)

    /** 讀取內部 RAM（記憶體搜尋用，不影響模擬）。 */
    fun peekRam(i: Int): Int = ram[i and 0x7FF]
    val ppu = Ppu(mapper)
    val apu = Apu(this)

    /** 目前按下的按鍵（Pad 位元），索引 0 為 1P、1 為 2P。 */
    val pad = IntArray(2)
    private val latch = IntArray(2)
    private var strobe = false

    /** OAM DMA 造成的 CPU 暫停週期數。 */
    var stall = 0

    /** 目前這道指令在讀取記憶體前已經過的 CPU 週期數，以及 PPU 已提前執行的週期數。 */
    var cpuPre = 0
    var ppuAhead = 0

    // 金手指
    private var ggAddr = IntArray(0)
    private var ggVal = IntArray(0)
    private var ggCmp = IntArray(0)
    private var ramAddr = IntArray(0)
    private var ramVal = IntArray(0)

    fun setPatches(list: List<CheatPatch>) {
        val roms = list.filterIsInstance<CheatPatch.Rom>()
        ggAddr = IntArray(roms.size) { roms[it].addr }
        ggVal = IntArray(roms.size) { roms[it].value }
        ggCmp = IntArray(roms.size) { roms[it].compare }
        val rams = list.filterIsInstance<CheatPatch.Ram>()
        ramAddr = IntArray(rams.size) { rams[it].addr }
        ramVal = IntArray(rams.size) { rams[it].value }
    }

    /** 每一格開始時呼叫，把 RAM 碼寫入記憶體。 */
    fun applyRamPatches() {
        for (k in ramAddr.indices) {
            val a = ramAddr[k]
            if (a < 0x2000) ram[a and 0x7FF] = ramVal[k]
            else mapper.prgRam[a - 0x6000] = ramVal[k].toByte()
        }
    }

    private fun patched(addr: Int, v: Int): Int {
        for (k in ggAddr.indices) {
            if (ggAddr[k] == addr && (ggCmp[k] < 0 || ggCmp[k] == v)) return ggVal[k]
        }
        return v
    }

    fun cpuRead(addr: Int): Int = when {
        addr < 0x2000 -> ram[addr and 0x7FF]
        addr < 0x4000 -> {
            // 讀 $2002 時，PPU 要先追到這次讀取發生的時間點（指令內部第幾個週期），
            // 否則等待垂直空白的輪詢迴圈會永遠錯過旗標
            if ((addr and 7) == 2) {
                val n = cpuPre * 3 - ppuAhead
                for (i in 0 until n) ppu.step()
                if (n > 0) ppuAhead += n
            }
            ppu.readReg(addr and 7)
        }
        addr == 0x4015 -> apu.readStatus()
        addr == 0x4016 -> readPad(0)
        addr == 0x4017 -> readPad(1)
        addr < 0x4020 -> 0
        else -> {
            val v = mapper.cpuRead(addr)
            if (ggAddr.isNotEmpty() && addr >= 0x8000) patched(addr, v) else v
        }
    }

    fun cpuWrite(addr: Int, v: Int) {
        when {
            addr < 0x2000 -> ram[addr and 0x7FF] = v
            addr < 0x4000 -> ppu.writeReg(addr and 7, v)
            addr == 0x4014 -> {
                val base = v shl 8
                for (i in 0 until 256) {
                    ppu.oam[(ppu.oamAddr + i) and 0xFF] = cpuRead(base or i)
                }
                stall += 513
            }
            addr == 0x4016 -> {
                strobe = (v and 1) != 0
                if (strobe) {
                    latch[0] = pad[0]
                    latch[1] = pad[1]
                }
            }
            addr < 0x4018 -> apu.write(addr, v)
            addr < 0x4020 -> {}
            else -> mapper.cpuWrite(addr, v)
        }
    }

    private fun readPad(i: Int): Int {
        if (strobe) latch[i] = pad[i]
        val bit = latch[i] and 1
        latch[i] = (latch[i] shr 1) or 0x80
        return bit or 0x40
    }

    fun save(o: DataOutputStream) {
        o.writeInts(ram)
        o.writeInts(latch)
        o.writeBoolean(strobe)
        o.writeInt(stall)
    }

    fun load(i: DataInputStream) {
        i.readInts(ram)
        i.readInts(latch)
        strobe = i.readBoolean()
        stall = i.readInt()
    }
}
