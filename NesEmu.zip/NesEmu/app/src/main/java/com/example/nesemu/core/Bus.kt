package com.example.nesemu.core

/** 手把按鍵位元。 */
object Pad {
    const val A = 0x01
    const val B = 0x02
    const val SELECT = 0x04
    const val START = 0x08
    const val UP = 0x10
    const val DOWN = 0x20
    const val LEFT = 0x40
    const val RIGHT = 0x80
}

/** CPU 位址匯流排：RAM、PPU/APU 暫存器、手把與卡帶。 */
class Bus(val mapper: Mapper) {
    private val ram = IntArray(2048)
    val ppu = Ppu(mapper)
    val apu = Apu(this)

    /** 目前按下的按鍵（Pad 位元），索引 0 為 1P、1 為 2P。 */
    val pad = IntArray(2)
    private val latch = IntArray(2)
    private var strobe = false

    /** OAM DMA 造成的 CPU 暫停週期數。 */
    var stall = 0

    fun cpuRead(addr: Int): Int = when {
        addr < 0x2000 -> ram[addr and 0x7FF]
        addr < 0x4000 -> ppu.readReg(addr and 7)
        addr == 0x4015 -> apu.readStatus()
        addr == 0x4016 -> readPad(0)
        addr == 0x4017 -> readPad(1)
        addr < 0x4020 -> 0
        else -> mapper.cpuRead(addr)
    }

    fun cpuWrite(addr: Int, v: Int) {
        when {
            addr < 0x2000 -> ram[addr and 0x7FF] = v
            addr < 0x4000 -> ppu.writeReg(addr and 7, v)
            addr == 0x4014 -> {
                val base = v shl 8
                for (i in 0 until 256) {
                    ppu.oam[(ppu.oamAddr + i) and 0xFF] = cpuRead(base or i)
                }
                stall += 513
            }
            addr == 0x4016 -> {
                strobe = (v and 1) != 0
                if (strobe) {
                    latch[0] = pad[0]
                    latch[1] = pad[1]
                }
            }
            addr < 0x4018 -> apu.write(addr, v)
            addr < 0x4020 -> {}
            else -> mapper.cpuWrite(addr, v)
        }
    }

    private fun readPad(i: Int): Int {
        if (strobe) latch[i] = pad[i]
        val bit = latch[i] and 1
        latch[i] = (latch[i] shr 1) or 0x80
        return bit or 0x40
    }
}
