package com.example.nesemu.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.example.nesemu.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 首頁：選擇 ROM、最近遊玩（附最後畫面縮圖，長按可管理）、
 * 以及「ROM 資料夾」中的所有遊戲。
 */
class MainActivity : Activity() {
    private lateinit var settings: Settings
    private lateinit var recentBox: LinearLayout
    private lateinit var folderBox: LinearLayout
    private lateinit var folderTitle: TextView
    private val dp by lazy { resources.displayMetrics.density }
    private fun px(v: Int) = (v * dp).toInt()

    /** 每次掃描資料夾的序號；舊的掃描結果晚到時丟掉。 */
    private var scanSeq = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = Settings(this)
        val pad = px(20)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(pad, pad * 2, pad, 0)
        }
        root.addView(TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 28f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = getString(R.string.home_subtitle)
            textSize = 14f
            setTextColor(SUB)
            setPadding(0, 0, 0, px(14))
        })

        // 上方兩顆大按鈕
        val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btnRow.addView(bigButton("📄", "開啟 ROM 檔") { pickRom() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = px(6) })
        btnRow.addView(bigButton("📁", "設定 ROM 資料夾") { pickFolder() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = px(6) })
        root.addView(btnRow)

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, pad)
        }
        body.addView(sectionTitle(getString(R.string.recent_games)))
        recentBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(recentBox)
        folderTitle = sectionTitle("ROM 資料夾")
        body.addView(folderTitle)
        folderBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(folderBox)

        root.addView(
            ScrollView(this).apply { addView(body) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refreshRecent()
        refreshFolder()
    }

    // ---- 外觀小工具 ----
    private fun card(): GradientDrawable = GradientDrawable().apply {
        cornerRadius = 12 * dp
        setColor(CARD)
    }

    private fun bigButton(icon: String, label: String, onClick: () -> Unit): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                cornerRadius = 12 * dp
                setColor(ACCENT)
            }
            setPadding(px(8), px(14), px(8), px(14))
            isClickable = true
            setOnClickListener { onClick() }
            addView(TextView(context).apply {
                text = icon
                textSize = 18f
                setPadding(0, 0, px(6), 0)
            })
            addView(TextView(context).apply {
                text = label
                textSize = 15f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
            })
        }

    private fun sectionTitle(t: String) = TextView(this).apply {
        text = t
        textSize = 16f
        setTextColor(TITLE)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, px(20), 0, px(8))
    }

    private fun hint(t: String) = TextView(this).apply {
        text = t
        setTextColor(SUB)
        textSize = 13f
        setPadding(px(2), 0, 0, px(4))
    }

    // ---- 選檔 ----
    private fun pickRom() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, REQ_PICK)
    }

    private fun pickFolder() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try {
            startActivityForResult(i, REQ_FOLDER)
        } catch (_: Throwable) {
            Toast.makeText(this, "這支手機不支援選擇資料夾", Toast.LENGTH_SHORT).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Throwable) {
        }
        when (requestCode) {
            REQ_PICK -> {
                val name = displayName(uri) ?: getString(R.string.app_name)
                launch(uri, name)
            }
            REQ_FOLDER -> {
                settings.romFolder = uri.toString()
                refreshFolder()
            }
        }
    }

    private fun launch(uri: Uri, name: String) {
        RecentStore.add(this, uri.toString(), name)
        startActivity(Intent(this, EmulatorActivity::class.java).setData(uri))
    }

    private fun displayName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (_: Throwable) {
        null
    }

    private fun prettyName(name: String) = name.removeSuffix(".nes").removeSuffix(".NES")

    // ---- 最近遊玩 ----
    private fun refreshRecent() {
        recentBox.removeAllViews()
        val items = RecentStore.load(this)
        if (items.isEmpty()) {
            recentBox.addView(hint(getString(R.string.no_recent)))
            return
        }
        recentBox.addView(hint("長按遊戲可移除紀錄或刪除存檔"))
        val fmt = SimpleDateFormat("MM/dd HH:mm", Locale.getDefault())
        for ((uriStr, name) in items) {
            val crc = RomIndex.get(this, uriStr)
            val auto = crc?.let { StateStore.file(this, it, StateStore.AUTO_SLOT) }
            val thumb = crc?.let { StateStore.thumb(this, it, StateStore.AUTO_SLOT) }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = card()
                setPadding(px(10), px(10), px(12), px(10))
                isClickable = true
                isLongClickable = true
                setOnClickListener { launch(Uri.parse(uriStr), name) }
                setOnLongClickListener { manageRecent(uriStr, name, crc); true }
            }
            val img = ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                setBackgroundColor(Color.BLACK)
                if (thumb != null && thumb.exists()) {
                    try {
                        setImageBitmap(BitmapFactory.decodeFile(thumb.path))
                    } catch (_: Throwable) {
                    }
                }
            }
            if (thumb == null || !thumb.exists()) {
                row.addView(TextView(this).apply {
                    text = "🎮"
                    textSize = 30f
                    gravity = Gravity.CENTER
                    setBackgroundColor(0xFF111317.toInt())
                }, LinearLayout.LayoutParams(px(96), px(90)))
            } else {
                row.addView(img, LinearLayout.LayoutParams(px(96), px(90)))
            }
            val texts = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(px(14), 0, 0, 0)
            }
            texts.addView(TextView(this).apply {
                text = prettyName(name)
                textSize = 16f
                setTextColor(Color.WHITE)
                maxLines = 2
            })
            texts.addView(TextView(this).apply {
                text = if (auto != null && auto.exists()) "上次遊玩 ${fmt.format(Date(auto.lastModified()))}・可接續" else "點一下開始遊戲"
                textSize = 12f
                setTextColor(if (auto != null && auto.exists()) LINK else SUB)
                setPadding(0, px(4), 0, 0)
            })
            row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            recentBox.addView(row, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = px(8) })
        }
    }

    private fun manageRecent(uri: String, name: String, crc: Long?) {
        val opts = mutableListOf("從最近遊玩移除")
        if (crc != null) opts.add("刪除此遊戲所有即時存檔（含自動存檔）")
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle(prettyName(name))
            .setItems(opts.toTypedArray()) { _, i ->
                when (i) {
                    0 -> {
                        RecentStore.remove(this, uri)
                        refreshRecent()
                    }
                    1 -> AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                        .setTitle("確定刪除？")
                        .setMessage("「${prettyName(name)}」的 6 個存檔欄位與自動存檔都會刪除，無法復原。\n（遊戲內建的電池存檔不受影響）")
                        .setPositiveButton("刪除") { _, _ ->
                            StateStore.deleteAll(this, crc!!)
                            Toast.makeText(this, "已刪除存檔", Toast.LENGTH_SHORT).show()
                            refreshRecent()
                        }
                        .setNegativeButton("取消", null)
                        .show()
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    // ---- ROM 資料夾 ----
    private fun refreshFolder() {
        folderBox.removeAllViews()
        val tree = settings.romFolder
        if (tree == null) {
            folderTitle.text = "ROM 資料夾"
            folderBox.addView(hint("按上方「設定 ROM 資料夾」選擇放遊戲的資料夾，裡面的 .nes 會自動列在這裡。"))
            return
        }
        folderTitle.text = "ROM 資料夾"
        folderBox.addView(hint("搜尋中…"))
        val seq = ++scanSeq
        Thread {
            val found = try {
                scanTree(Uri.parse(tree))
            } catch (_: Throwable) {
                null
            }
            runOnUiThread {
                if (seq != scanSeq || isFinishing) return@runOnUiThread
                showFolder(found)
            }
        }.start()
    }

    /** 列出資料夾（含三層子資料夾）中的 .nes 檔：回傳 (名稱, 文件 URI)。 */
    private fun scanTree(tree: Uri): List<Pair<String, Uri>> {
        val out = mutableListOf<Pair<String, Uri>>()
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        fun walk(docId: String, depth: Int) {
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            contentResolver.query(
                children,
                arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE,
                ),
                null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val name = c.getString(1) ?: continue
                    val mime = c.getString(2) ?: ""
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if (depth < 3) walk(id, depth + 1)
                    } else if (name.endsWith(".nes", ignoreCase = true)) {
                        out.add(name to DocumentsContract.buildDocumentUriUsingTree(tree, id))
                    }
                }
            }
        }
        walk(rootId, 0)
        return out.sortedBy { it.first.lowercase(Locale.ROOT) }
    }

    private fun showFolder(found: List<Pair<String, Uri>>?) {
        folderBox.removeAllViews()
        if (found == null) {
            folderBox.addView(hint("無法讀取這個資料夾，請重新設定。"))
            return
        }
        folderTitle.text = "ROM 資料夾（${found.size} 個遊戲）"
        if (found.isEmpty()) {
            folderBox.addView(hint("這個資料夾裡沒有 .nes 檔。"))
        }
        for ((name, uri) in found) {
            folderBox.addView(TextView(this).apply {
                text = "🎮  " + prettyName(name)
                textSize = 15f
                setTextColor(Color.WHITE)
                background = card()
                setPadding(px(14), px(12), px(14), px(12))
                setOnClickListener { launch(uri, name) }
            }, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = px(6) })
        }
        folderBox.addView(TextView(this).apply {
            text = "取消資料夾設定"
            textSize = 13f
            setTextColor(LINK)
            setPadding(px(2), px(8), 0, 0)
            setOnClickListener {
                settings.romFolder = null
                refreshFolder()
            }
        })
    }

    private companion object {
        const val REQ_PICK = 1001
        const val REQ_FOLDER = 1002
        val BG = Color.parseColor("#14161A")
        val CARD = Color.parseColor("#22262C")
        val ACCENT = Color.parseColor("#B3261E")
        val TITLE = Color.parseColor("#E8EAED")
        val SUB = Color.parseColor("#9AA0A6")
        val LINK = Color.parseColor("#8AB4F8")
    }
}
