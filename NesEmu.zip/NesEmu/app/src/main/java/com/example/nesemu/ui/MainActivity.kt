package com.example.nesemu.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.example.nesemu.R

/** 首頁：選擇 ROM 檔案，並列出最近遊玩的遊戲。 */
class MainActivity : Activity() {
    private lateinit var listBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#14161A"))
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 28f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = getString(R.string.home_subtitle)
            textSize = 14f
            setTextColor(Color.parseColor("#9AA0A6"))
            setPadding(0, 0, 0, pad)
        })
        root.addView(Button(this).apply {
            text = getString(R.string.choose_rom)
            setOnClickListener { pickRom() }
        })
        root.addView(TextView(this).apply {
            text = getString(R.string.recent_games)
            textSize = 16f
            setTextColor(Color.parseColor("#E8EAED"))
            setPadding(0, pad, 0, pad / 2)
        })
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(
            ScrollView(this).apply { addView(listBox) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refreshRecent()
    }

    private fun pickRom() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, REQ_PICK)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Throwable) {
        }
        val name = displayName(uri) ?: getString(R.string.app_name)
        addRecent(uri, name)
        launch(uri)
    }

    private fun launch(uri: Uri) {
        startActivity(Intent(this, EmulatorActivity::class.java).setData(uri))
    }

    private fun displayName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (_: Throwable) {
        null
    }

    // ---- 最近遊玩紀錄（SharedPreferences，每行：uri \t 名稱） ----
    private fun loadRecent(): List<Pair<String, String>> {
        val raw = getSharedPreferences("recent", Context.MODE_PRIVATE).getString("list", "") ?: ""
        return raw.split('\n').filter { it.contains('\t') }.map {
            val p = it.split('\t', limit = 2)
            p[0] to p[1]
        }
    }

    private fun addRecent(uri: Uri, name: String) {
        val list = loadRecent().filter { it.first != uri.toString() }.toMutableList()
        list.add(0, uri.toString() to name.replace('\n', ' ').replace('\t', ' '))
        val raw = list.take(10).joinToString("\n") { it.first + "\t" + it.second }
        getSharedPreferences("recent", Context.MODE_PRIVATE).edit().putString("list", raw).apply()
    }

    private fun refreshRecent() {
        listBox.removeAllViews()
        val items = loadRecent()
        if (items.isEmpty()) {
            listBox.addView(TextView(this).apply {
                text = getString(R.string.no_recent)
                setTextColor(Color.parseColor("#9AA0A6"))
            })
            return
        }
        val pad = (14 * resources.displayMetrics.density).toInt()
        for ((uriStr, name) in items) {
            listBox.addView(TextView(this).apply {
                text = name
                textSize = 16f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(Color.parseColor("#22262C"))
                setPadding(pad, pad, pad, pad)
                setOnClickListener {
                    try {
                        launch(Uri.parse(uriStr))
                    } catch (_: Throwable) {
                        Toast.makeText(context, getString(R.string.error_open_file), Toast.LENGTH_SHORT).show()
                    }
                }
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = pad / 3 }
                visibility = View.VISIBLE
            })
        }
    }

    private companion object {
        const val REQ_PICK = 1001
    }
}
