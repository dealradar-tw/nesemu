package com.example.nesemu.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import com.example.nesemu.R
import com.example.nesemu.core.Pad
import kotlin.math.hypot

/** 透明的虛擬按鍵層：十字鍵、A、B、選擇、開始。支援多點觸控。 */
class ControlsView(context: Context) : View(context) {
    /** 目前按下的按鍵（Pad 位元），可由模擬執行緒讀取。 */
    @Volatile
    var state = 0
        private set

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.argb(150, 255, 255, 255)
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(220, 255, 255, 255)
        textAlign = Paint.Align.CENTER
    }

    private var dpadX = 0f
    private var dpadY = 0f
    private var dpadR = 0f
    private var aX = 0f
    private var aY = 0f
    private var bX = 0f
    private var bY = 0f
    private var btnR = 0f
    private val selectRect = RectF()
    private val startRect = RectF()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val fw = w.toFloat()
        val fh = h.toFloat()
        if (w >= h) {
            dpadR = fh * 0.2f
            dpadX = fw * 0.04f + dpadR * 1.2f
            dpadY = fh * 0.66f
            btnR = fh * 0.105f
            aX = fw * 0.93f - btnR
            aY = fh * 0.60f
            bX = aX - btnR * 2.3f
            bY = aY + btnR * 1.0f
            val pw = fh * 0.2f
            val ph = fh * 0.09f
            val py = fh * 0.88f
            selectRect.set(fw * 0.5f - pw - 10f, py, fw * 0.5f - 10f, py + ph)
            startRect.set(fw * 0.5f + 10f, py, fw * 0.5f + pw + 10f, py + ph)
        } else {
            val gameBottom = GameView.gameRect(w, h).bottom
            val areaH = fh - gameBottom
            val cy = gameBottom + areaH * 0.42f
            dpadR = fw * 0.19f
            dpadX = fw * 0.05f + dpadR * 1.1f
            dpadY = cy
            btnR = fw * 0.1f
            aX = fw * 0.93f - btnR
            aY = cy - btnR * 0.6f
            bX = aX - btnR * 2.3f
            bY = aY + btnR * 1.1f
            val pw = fw * 0.2f
            val ph = fw * 0.08f
            val py = fh - areaH * 0.14f - ph
            selectRect.set(fw * 0.5f - pw - 12f, py, fw * 0.5f - 12f, py + ph)
            startRect.set(fw * 0.5f + 12f, py, fw * 0.5f + pw + 12f, py + ph)
        }
        stroke.strokeWidth = (btnR * 0.06f).coerceAtLeast(2f)
    }

    private fun hit(x: Float, y: Float): Int {
        var s = 0
        val dx = x - dpadX
        val dy = y - dpadY
        if (hypot(dx, dy) <= dpadR * 1.35f) {
            val dead = dpadR * 0.28f
            if (dx < -dead) s = s or Pad.LEFT
            if (dx > dead) s = s or Pad.RIGHT
            if (dy < -dead) s = s or Pad.UP
            if (dy > dead) s = s or Pad.DOWN
        }
        if (hypot(x - aX, y - aY) <= btnR * 1.3f) s = s or Pad.A
        if (hypot(x - bX, y - bY) <= btnR * 1.3f) s = s or Pad.B
        if (inflated(selectRect).contains(x, y)) s = s or Pad.SELECT
        if (inflated(startRect).contains(x, y)) s = s or Pad.START
        return s
    }

    private val tmp = RectF()
    private fun inflated(r: RectF): RectF {
        tmp.set(r)
        tmp.inset(-r.height() * 0.3f, -r.height() * 0.4f)
        return tmp
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        var s = 0
        val action = e.actionMasked
        if (action != MotionEvent.ACTION_UP && action != MotionEvent.ACTION_CANCEL) {
            val skip = if (action == MotionEvent.ACTION_POINTER_UP) e.actionIndex else -1
            for (i in 0 until e.pointerCount) {
                if (i == skip) continue
                s = s or hit(e.getX(i), e.getY(i))
            }
        }
        if (s != state) {
            if ((s and state.inv()) != 0) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            state = s
            invalidate()
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        // 十字鍵
        fill.color = Color.argb(50, 255, 255, 255)
        canvas.drawCircle(dpadX, dpadY, dpadR, fill)
        canvas.drawCircle(dpadX, dpadY, dpadR, stroke)
        arrow(canvas, 0f, -1f, Pad.UP)
        arrow(canvas, 0f, 1f, Pad.DOWN)
        arrow(canvas, -1f, 0f, Pad.LEFT)
        arrow(canvas, 1f, 0f, Pad.RIGHT)

        // A / B
        round(canvas, aX, aY, context.getString(R.string.btn_a), Pad.A)
        round(canvas, bX, bY, context.getString(R.string.btn_b), Pad.B)

        // 選擇 / 開始
        pill(canvas, selectRect, context.getString(R.string.btn_select), Pad.SELECT)
        pill(canvas, startRect, context.getString(R.string.btn_start), Pad.START)
    }

    private fun arrow(canvas: Canvas, ux: Float, uy: Float, bit: Int) {
        val c = dpadR * 0.62f
        val cx = dpadX + ux * c
        val cy = dpadY + uy * c
        val sz = dpadR * 0.2f
        val p = Path()
        // 指向 (ux, uy) 的三角形
        p.moveTo(cx + ux * sz, cy + uy * sz)
        p.lineTo(cx - ux * sz - uy * sz, cy - uy * sz + ux * sz)
        p.lineTo(cx - ux * sz + uy * sz, cy - uy * sz - ux * sz)
        p.close()
        fill.color = if ((state and bit) != 0) Color.argb(230, 255, 255, 255) else Color.argb(120, 255, 255, 255)
        canvas.drawPath(p, fill)
    }

    private fun round(canvas: Canvas, cx: Float, cy: Float, label: String, bit: Int) {
        val on = (state and bit) != 0
        fill.color = if (on) Color.argb(200, 230, 60, 60) else Color.argb(90, 200, 40, 40)
        canvas.drawCircle(cx, cy, btnR, fill)
        canvas.drawCircle(cx, cy, btnR, stroke)
        text.textSize = btnR * 0.9f
        canvas.drawText(label, cx, cy + text.textSize * 0.35f, text)
    }

    private fun pill(canvas: Canvas, r: RectF, label: String, bit: Int) {
        val on = (state and bit) != 0
        fill.color = if (on) Color.argb(200, 255, 255, 255) else Color.argb(70, 255, 255, 255)
        canvas.drawRoundRect(r, r.height() / 2f, r.height() / 2f, fill)
        canvas.drawRoundRect(r, r.height() / 2f, r.height() / 2f, stroke)
        text.textSize = r.height() * 0.5f
        canvas.drawText(label, r.centerX(), r.centerY() + text.textSize * 0.35f, text)
    }
}
