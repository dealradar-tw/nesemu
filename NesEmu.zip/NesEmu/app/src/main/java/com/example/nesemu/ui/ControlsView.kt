package com.example.nesemu.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import com.example.nesemu.R
import com.example.nesemu.core.Pad
import kotlin.math.hypot

/**
 * 透明的虛擬按鍵層：十字鍵、A、B、連A、連B、選擇、開始，
 * 以及存檔、讀檔、快轉、選單四個功能鍵。支援多點觸控。
 */
class ControlsView(context: Context) : View(context) {
    /** 目前按下的遊戲按鍵（Pad 位元，含連發位元），可由模擬執行緒讀取。 */
    @Volatile
    var state = 0
        private set

    /** 功能鍵被點下時的回呼（ACTION_SAVE 等）。 */
    var onAction: ((Int) -> Unit)? = null

    /** 遊戲按鍵剛被按下時的回呼（用來結束「暫停等待按鍵」狀態）。 */
    var onPress: (() -> Unit)? = null

    /** 為 true 時在遊戲畫面上顯示「已暫停」提示。 */
    var holdLabel = false
        set(v) {
            field = v
            invalidate()
        }

    /** 快轉中時顯示的文字（例如「▶▶ 2x」），null 表示未快轉。 */
    var fastLabel: String? = null
        set(v) {
            field = v
            invalidate()
        }

    /** 按鍵大小倍率（設定的 85%～125%）。 */
    var scale = 1f

    /** 按鍵不透明度倍率（0.5＝淡、1＝標準、1.6＝明顯）。 */
    var alphaMul = 1f

    /** 是否震動回饋。 */
    var haptics = true

    private fun al(a: Int): Int = (a * alphaMul).toInt().coerceIn(0, 255)

    private fun buzz() {
        if (haptics) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.argb(al(150), 255, 255, 255)
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(al(220), 255, 255, 255)
        textAlign = Paint.Align.CENTER
    }

    private var dpadX = 0f
    private var dpadY = 0f
    private var dpadR = 0f
    private var aX = 0f
    private var aY = 0f
    private var bX = 0f
    private var bY = 0f
    private var btnR = 0f
    private var tAX = 0f
    private var tAY = 0f
    private var tBX = 0f
    private var tBY = 0f
    private var tR = 0f
    private val selectRect = RectF()
    private val startRect = RectF()
    private val utilRects = Array(6) { RectF() }
    /** 功能鍵由左到右（橫式：左側由上到下、再右側由上到下）的排列：倒轉、快轉、1P/2P、存檔、讀檔、選單。 */
    private val utilOrder = intArrayOf(4, 2, 5, 0, 1, 3)
    private val utilLabels = intArrayOf(R.string.btn_save, R.string.btn_load, R.string.btn_fast, R.string.btn_menu, R.string.btn_rewind, R.string.btn_menu)

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        layoutButtons(w, h)
    }

    /** 畫面比例改變後重新計算按鍵位置。 */
    fun relayout() {
        layoutButtons(width, height)
        invalidate()
    }

    private fun layoutButtons(w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        val fw = w.toFloat()
        val fh = h.toFloat()
        val sc = scale
        if (w >= h) {
            dpadR = minOf(fh * 0.2f * sc, fh * 0.24f)
            dpadX = fw * 0.04f + dpadR * 1.2f
            dpadY = fh * 0.66f
            btnR = minOf(fh * 0.105f * sc, fh * 0.12f)
            aX = fw * 0.93f - btnR
            aY = fh * 0.60f
            bX = aX - btnR * 2.3f
            bY = aY + btnR * 1.0f
            val pw = fh * 0.2f
            val ph = fh * 0.09f
            val py = fh * 0.88f
            selectRect.set(fw * 0.5f - pw - 10f, py, fw * 0.5f - 10f, py + ph)
            startRect.set(fw * 0.5f + 10f, py, fw * 0.5f + pw + 10f, py + ph)
            // 功能鍵：左上角三顆（倒轉、快轉、1P/2P），右上角三顆（存檔、讀檔、選單）
            val uw = fh * 0.19f
            val uh = fh * 0.07f
            val gap = fh * 0.015f
            for (slot in utilOrder.indices) {
                val k = utilOrder[slot]
                val top = fh * 0.03f + (slot % 3) * (uh + gap)
                val left = if (slot < 3) fh * 0.03f else fw - fh * 0.03f - uw
                utilRects[k].set(left, top, left + uw, top + uh)
            }
        } else {
            val gameBottom = GameView.gameRect(w, h).bottom
            val areaH = fh - gameBottom
            val cy = gameBottom + areaH * 0.45f
            dpadR = minOf(fw * 0.19f * sc, fw * 0.21f)
            dpadX = (if (sc > 1f) fw * 0.03f else fw * 0.05f) + dpadR * (if (sc > 1f) 1.05f else 1.1f)
            dpadY = cy
            btnR = minOf(fw * 0.1f * sc, fw * 0.108f)
            aX = (if (sc > 1f) fw * 0.97f else fw * 0.93f) - btnR
            aY = cy - btnR * 0.6f
            bX = aX - btnR * 2.3f
            bY = aY + btnR * 1.1f
            val pw = fw * 0.2f
            val ph = fw * 0.08f
            val py = fh - areaH * 0.12f - ph
            selectRect.set(fw * 0.5f - pw - 12f, py, fw * 0.5f - 12f, py + ph)
            startRect.set(fw * 0.5f + 12f, py, fw * 0.5f + pw + 12f, py + ph)
            // 功能鍵：遊戲畫面下方一列
            val uw = fw * 0.14f
            val uh = fw * 0.075f
            val gap = fw * 0.015f
            val x0 = (fw - (6 * uw + 5 * gap)) / 2f
            val top = gameBottom + areaH * 0.02f
            for (slot in utilOrder.indices) {
                val k = utilOrder[slot]
                val left = x0 + slot * (uw + gap)
                utilRects[k].set(left, top, left + uw, top + uh)
            }
        }
        tR = btnR * 0.7f
        tAX = aX
        tAY = aY - btnR * 2.3f
        if (w >= h) tAY = maxOf(tAY, fh * 0.28f + tR * 0.9f)
        tBX = bX
        tBY = bY - btnR * 2.3f
        if (w >= h) tBY = maxOf(tBY, fh * 0.28f + tR * 0.9f)
        stroke.strokeWidth = (btnR * 0.06f).coerceAtLeast(2f)
    }

    private fun hit(x: Float, y: Float): Int {
        var s = 0
        val dx = x - dpadX
        val dy = y - dpadY
        if (hypot(dx, dy) <= dpadR * 1.35f) {
            val dead = dpadR * 0.28f
            if (dx < -dead) s = s or Pad.LEFT
            if (dx > dead) s = s or Pad.RIGHT
            if (dy < -dead) s = s or Pad.UP
            if (dy > dead) s = s or Pad.DOWN
        }
        if (hypot(x - aX, y - aY) <= btnR * 1.3f) s = s or Pad.A
        if (hypot(x - bX, y - bY) <= btnR * 1.3f) s = s or Pad.B
        if (hypot(x - tAX, y - tAY) <= tR * 1.4f) s = s or Pad.TURBO_A
        if (hypot(x - tBX, y - tBY) <= tR * 1.4f) s = s or Pad.TURBO_B
        if (inflated(selectRect).contains(x, y)) s = s or Pad.SELECT
        if (inflated(startRect).contains(x, y)) s = s or Pad.START
        if (inflated(utilRects[4]).contains(x, y)) s = s or Pad.REWIND
        return s
    }

    private val tmp = RectF()
    private fun inflated(r: RectF): RectF {
        tmp.set(r)
        tmp.inset(-r.height() * 0.3f, -r.height() * 0.4f)
        return tmp
    }

    /** 兩指縮放回呼：(縮放比例, 中心 x, 中心 y, 中心位移 x, 中心位移 y)。 */
    var onPinch: ((Float, Float, Float, Float, Float) -> Unit)? = null
    private var pinching = false
    private var pinchDist = 0f
    private var pinchCx = 0f
    private var pinchCy = 0f

    private fun onUtil(x: Float, y: Float): Boolean {
        for (k in utilRects.indices) if (inflated(utilRects[k]).contains(x, y)) return true
        return false
    }

    /** 處理兩指縮放；回傳 true 表示這次事件已被縮放吃掉（不當作按鍵）。 */
    private fun handlePinch(e: MotionEvent): Boolean {
        val action = e.actionMasked
        if (!pinching) {
            if (action == MotionEvent.ACTION_POINTER_DOWN && e.pointerCount == 2 &&
                hit(e.getX(0), e.getY(0)) == 0 && hit(e.getX(1), e.getY(1)) == 0 &&
                !onUtil(e.getX(0), e.getY(0)) && !onUtil(e.getX(1), e.getY(1))
            ) {
                pinching = true
                pinchDist = hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1))
                pinchCx = (e.getX(0) + e.getX(1)) / 2f
                pinchCy = (e.getY(0) + e.getY(1)) / 2f
                return true
            }
            return false
        }
        when (action) {
            MotionEvent.ACTION_MOVE -> if (e.pointerCount >= 2) {
                val d = hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1))
                val cx = (e.getX(0) + e.getX(1)) / 2f
                val cy = (e.getY(0) + e.getY(1)) / 2f
                if (pinchDist > 10f && d > 10f) {
                    onPinch?.invoke(d / pinchDist, pinchCx, pinchCy, cx - pinchCx, cy - pinchCy)
                }
                pinchDist = d; pinchCx = cx; pinchCy = cy
            }
            MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (e.pointerCount <= 2 || action != MotionEvent.ACTION_POINTER_UP) pinching = false
            }
        }
        return true
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (handlePinch(e)) {
            if (state != 0) { state = 0; invalidate() }
            return true
        }
        val action = e.actionMasked

        // 功能鍵：只在手指剛按下時觸發一次
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            val idx = e.actionIndex
            val x = e.getX(idx)
            val y = e.getY(idx)
            for (k in intArrayOf(0, 1, 2, 3, 5)) {
                if (inflated(utilRects[k]).contains(x, y)) {
                    buzz()
                    onAction?.invoke(if (k == 5) ACTION_PLAYER else k + 1)
                    break
                }
            }
        }

        // 遊戲按鍵：每次事件重新計算所有手指
        var s = 0
        if (action != MotionEvent.ACTION_UP && action != MotionEvent.ACTION_CANCEL) {
            val skip = if (action == MotionEvent.ACTION_POINTER_UP) e.actionIndex else -1
            for (i in 0 until e.pointerCount) {
                if (i == skip) continue
                s = s or hit(e.getX(i), e.getY(i))
            }
        }
        if (s != state) {
            if ((s and state.inv()) != 0) buzz()
            val pressed = (s and state.inv()) != 0
            state = s
            invalidate()
            if (pressed) onPress?.invoke()
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        stroke.color = Color.argb(al(150), 255, 255, 255)
        text.color = Color.argb(al(220).coerceAtLeast(150), 255, 255, 255)
        // 十字鍵
        fill.color = Color.argb(al(50), 255, 255, 255)
        canvas.drawCircle(dpadX, dpadY, dpadR, fill)
        canvas.drawCircle(dpadX, dpadY, dpadR, stroke)
        arrow(canvas, 0f, -1f, Pad.UP)
        arrow(canvas, 0f, 1f, Pad.DOWN)
        arrow(canvas, -1f, 0f, Pad.LEFT)
        arrow(canvas, 1f, 0f, Pad.RIGHT)

        // A / B 與連發
        round(canvas, aX, aY, btnR, context.getString(R.string.btn_a), Pad.A, 200, 40, 40)
        round(canvas, bX, bY, btnR, context.getString(R.string.btn_b), Pad.B, 200, 40, 40)
        round(canvas, tAX, tAY, tR, context.getString(R.string.btn_turbo_a), Pad.TURBO_A, 40, 120, 200)
        round(canvas, tBX, tBY, tR, context.getString(R.string.btn_turbo_b), Pad.TURBO_B, 40, 120, 200)

        // 選擇 / 開始
        pill(canvas, selectRect, context.getString(R.string.btn_select), (state and Pad.SELECT) != 0)
        pill(canvas, startRect, context.getString(R.string.btn_start), (state and Pad.START) != 0)

        // 功能鍵
        for (k in utilRects.indices) {
            val active = (k == 2 && fastLabel != null) || (k == 4 && (state and Pad.REWIND) != 0)
            when (k) {
                2 -> iconPill(canvas, utilRects[k], 1, active)
                4 -> iconPill(canvas, utilRects[k], -1, active)
                5 -> pill(canvas, utilRects[k], "${player + 1}P", false)
                else -> pill(canvas, utilRects[k], context.getString(utilLabels[k]), active)
            }
        }

        // 暫停提示
        if (holdLabel) {
            val r = GameView.gameRect(width, height)
            text.textSize = (if (width >= height) height else width) * 0.055f
            canvas.drawText(context.getString(R.string.hold_hint), r.centerX(), r.centerY(), text)
        }

        if ((state and Pad.REWIND) != 0) {
            text.textSize = (if (width >= height) height else width) * 0.05f
            canvas.drawText("◀◀ 倒轉中", width / 2f, text.textSize * 1.4f, text)
        }

        // 快轉提示
        val fl = fastLabel
        if (fl != null) {
            text.textSize = (if (width >= height) height else width) * 0.05f
            canvas.drawText(fl, width / 2f, text.textSize * 1.4f, text)
        }
    }

    private fun arrow(canvas: Canvas, ux: Float, uy: Float, bit: Int) {
        val c = dpadR * 0.62f
        val cx = dpadX + ux * c
        val cy = dpadY + uy * c
        val sz = dpadR * 0.2f
        val p = Path()
        // 指向 (ux, uy) 的三角形
        p.moveTo(cx + ux * sz, cy + uy * sz)
        p.lineTo(cx - ux * sz - uy * sz, cy - uy * sz + ux * sz)
        p.lineTo(cx - ux * sz + uy * sz, cy - uy * sz - ux * sz)
        p.close()
        fill.color = if ((state and bit) != 0) Color.argb(al(230), 255, 255, 255) else Color.argb(al(120), 255, 255, 255)
        canvas.drawPath(p, fill)
    }

    private fun round(canvas: Canvas, cx: Float, cy: Float, r: Float, label: String, bit: Int, cr: Int, cg: Int, cb: Int) {
        val on = (state and bit) != 0
        fill.color = if (on) Color.argb(al(200), cr, cg, cb) else Color.argb(al(90), cr, cg, cb)
        canvas.drawCircle(cx, cy, r, fill)
        canvas.drawCircle(cx, cy, r, stroke)
        text.textSize = r * (if (label.length > 1) 0.7f else 0.9f)
        canvas.drawText(label, cx, cy + text.textSize * 0.35f, text)
    }

    /** 目前操作的玩家（0 = 1P，1 = 2P），由 Activity 設定。 */
    var player = 0

    /** 以兩個三角形畫出快轉（dir=1）或倒轉（dir=-1）圖示。 */
    private fun iconPill(canvas: Canvas, r: RectF, dir: Int, on: Boolean) {
        fill.color = if (on) Color.argb(al(200), 255, 255, 255) else Color.argb(al(70), 255, 255, 255)
        canvas.drawRoundRect(r, r.height() / 2f, r.height() / 2f, fill)
        canvas.drawRoundRect(r, r.height() / 2f, r.height() / 2f, stroke)
        val h = r.height() * 0.4f
        val w = h * 0.9f
        val cx = r.centerX()
        val cy = r.centerY()
        val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = if (on) Color.BLACK else Color.WHITE }
        for (i in 0..1) {
            val x0 = cx + (i - 1) * w + w * 0.5f
            val path = Path()
            if (dir > 0) {
                path.moveTo(x0 - w * 0.5f, cy - h / 2); path.lineTo(x0 + w * 0.5f, cy); path.lineTo(x0 - w * 0.5f, cy + h / 2)
            } else {
                path.moveTo(x0 + w * 0.5f, cy - h / 2); path.lineTo(x0 - w * 0.5f, cy); path.lineTo(x0 + w * 0.5f, cy + h / 2)
            }
            path.close()
            canvas.drawPath(path, ink)
        }
    }

    private fun pill(canvas: Canvas, r: RectF, label: String, on: Boolean) {
        fill.color = if (on) Color.argb(al(200), 255, 255, 255) else Color.argb(al(70), 255, 255, 255)
        canvas.drawRoundRect(r, r.height() / 2f, r.height() / 2f, fill)
        canvas.drawRoundRect(r, r.height() / 2f, r.height() / 2f, stroke)
        text.textSize = r.height() * 0.5f
        canvas.drawText(label, r.centerX(), r.centerY() + text.textSize * 0.35f, text)
    }

    companion object {
        const val ACTION_SAVE = 1
        const val ACTION_LOAD = 2
        const val ACTION_FAST = 3
        const val ACTION_MENU = 4
        const val ACTION_PLAYER = 5
    }
}
