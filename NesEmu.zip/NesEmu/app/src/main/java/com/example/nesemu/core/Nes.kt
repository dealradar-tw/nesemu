package com.example.nesemu.core

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream

/** 一台完整的 NES：CPU + PPU + APU + 卡帶。 */
class Nes(romData: ByteArray) {
    val cart: Cartridge = Cartridge.parse(romData)
    val mapper: Mapper = Mapper.create(cart)
    val bus = Bus(mapper)
    val cpu = Cpu(bus)
    val ppu: Ppu get() = bus.ppu
    val apu: Apu get() = bus.apu

    init {
        patchKnownBugs()
        cpu.reset()
    }

    /**
     * 吞食天地外傳（中文化）：戰鬥中「部將」畫面返回時，遊戲會把假名字型整批載回 CHR-RAM，
     * 卻沒有清掉文字圖塊快取，指令框就會取用到已被蓋掉的舊圖塊而變成亂碼。
     * 這裡讓該載入常式結尾改走遊戲自己的「清除快取」掛勾（$541C，與另一個載入常式相同做法）。
     * 以位元組特徵比對，找不到就不動。
     */
    private fun patchKnownBugs() {
        if (cart.mapperId != 4 || !cart.chrIsRam || cart.prg.size <= 512 * 1024) return
        val sig = intArrayOf(
            0xA9, 0x0E, 0x20, 0xE5, 0xC6, 0xA0, 0x10, 0xA9, 0x04, 0xA2, 0x80,
            0x20, 0xBB, 0xC5, 0x00, 0x94, 0x4C, 0xE1, 0xC6,
        )
        val prg = cart.prg
        val base = prg.size - 16384 // 固定在 $C000-$FFFF 的最後兩個 8KB bank
        var found = -1
        for (i in base until prg.size - sig.size) {
            var ok = true
            for (k in sig.indices) if ((prg[i + k].toInt() and 0xFF) != sig[k]) { ok = false; break }
            if (ok) { if (found >= 0) return; found = i }
        }
        if (found < 0) return
        // 另需確認 $541C 掛勾確實存在於卡帶（固定 bank 內有 4C 1C 54）
        var hook = false
        for (i in base until prg.size - 3) {
            if ((prg[i].toInt() and 0xFF) == 0x4C && (prg[i + 1].toInt() and 0xFF) == 0x1C &&
                (prg[i + 2].toInt() and 0xFF) == 0x54) { hook = true; break }
        }
        if (!hook) return
        prg[found + 17] = 0x1C
        prg[found + 18] = 0x54
    }

    /** 自動判斷是否需要加長垂直空白：大容量 MMC3 + CHR-RAM 的中文化卡帶。 */
    fun autoExtraLines(): Int =
        if (cart.mapperId == 4 && cart.chrIsRam && cart.prg.size > 512 * 1024) 70 else 0

    fun setPad(player: Int, state: Int) {
        bus.pad[player] = state and 0xFF
    }

    fun peekRam(i: Int): Int = bus.peekRam(i)

    /** 設定目前啟用的金手指（會取代先前的設定）。 */
    fun setCheats(patches: List<CheatPatch>) {
        bus.setPatches(patches)
    }

    /** 執行到下一次垂直空白開始（約 1/60 秒的遊戲時間）。 */
    fun runFrame() {
        val ppu = bus.ppu
        val apu = bus.apu
        bus.applyRamPatches()
        ppu.frameDone = false
        while (!ppu.frameDone) {
            val c = cpu.step()
            val rest = c * 3 - bus.ppuAhead
            bus.ppuAhead = 0
            for (i in 0 until rest) ppu.step()
            // 額外掃描線期間不推進 APU，音效節奏與聲音輸出量維持原本的 60Hz
            if (ppu.scanline <= 260) for (i in 0 until c) apu.step()
        }
    }

    /** 把整台機器目前的狀態序列化成位元組（即時存檔）。 */
    fun saveState(): ByteArray {
        val bytes = ByteArrayOutputStream()
        DataOutputStream(bytes).use { o ->
            o.writeInt(STATE_MAGIC)
            o.writeInt(cart.mapperId)
            o.writeInt(cart.prg.size)
            cpu.save(o)
            bus.save(o)
            ppu.save(o)
            apu.save(o)
            mapper.save(o)
        }
        return bytes.toByteArray()
    }

    /** 還原先前由 saveState() 產生的狀態（即時讀檔）。 */
    fun loadState(data: ByteArray) {
        val i = DataInputStream(ByteArrayInputStream(data))
        if (i.readInt() != STATE_MAGIC || i.readInt() != cart.mapperId || i.readInt() != cart.prg.size) {
            throw RomException("存檔與目前遊戲不符，或檔案格式不正確")
        }
        cpu.load(i)
        bus.load(i)
        ppu.load(i)
        apu.load(i)
        mapper.load(i)
    }

    private companion object {
        const val STATE_MAGIC = 0x4E455332 // "NES1"
    }
}
