package com.example.nesemu.core

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream

/** 一台完整的 NES：CPU + PPU + APU + 卡帶。 */
class Nes(romData: ByteArray) {
    val cart: Cartridge = Cartridge.parse(romData)
    val mapper: Mapper = Mapper.create(cart)
    val bus = Bus(mapper)
    val cpu = Cpu(bus)
    val ppu: Ppu get() = bus.ppu
    val apu: Apu get() = bus.apu

    init {
        cpu.reset()
    }

    fun setPad(player: Int, state: Int) {
        bus.pad[player] = state and 0xFF
    }

    /** 設定目前啟用的金手指（會取代先前的設定）。 */
    fun setCheats(patches: List<CheatPatch>) {
        bus.setPatches(patches)
    }

    /** 執行到下一次垂直空白開始（約 1/60 秒的遊戲時間）。 */
    fun runFrame() {
        val ppu = bus.ppu
        val apu = bus.apu
        bus.applyRamPatches()
        ppu.frameDone = false
        while (!ppu.frameDone) {
            val c = cpu.step()
            val rest = c * 3 - bus.ppuAhead
            bus.ppuAhead = 0
            for (i in 0 until rest) ppu.step()
            for (i in 0 until c) apu.step()
        }
    }

    /** 把整台機器目前的狀態序列化成位元組（即時存檔）。 */
    fun saveState(): ByteArray {
        val bytes = ByteArrayOutputStream()
        DataOutputStream(bytes).use { o ->
            o.writeInt(STATE_MAGIC)
            o.writeInt(cart.mapperId)
            o.writeInt(cart.prg.size)
            cpu.save(o)
            bus.save(o)
            ppu.save(o)
            apu.save(o)
            mapper.save(o)
        }
        return bytes.toByteArray()
    }

    /** 還原先前由 saveState() 產生的狀態（即時讀檔）。 */
    fun loadState(data: ByteArray) {
        val i = DataInputStream(ByteArrayInputStream(data))
        if (i.readInt() != STATE_MAGIC || i.readInt() != cart.mapperId || i.readInt() != cart.prg.size) {
            throw RomException("存檔與目前遊戲不符，或檔案格式不正確")
        }
        cpu.load(i)
        bus.load(i)
        ppu.load(i)
        apu.load(i)
        mapper.load(i)
    }

    private companion object {
        const val STATE_MAGIC = 0x4E455332 // "NES1"
    }
}
