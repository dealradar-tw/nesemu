package com.example.nesemu.core

/** 一台完整的 NES：CPU + PPU + APU + 卡帶。 */
class Nes(romData: ByteArray) {
    val cart: Cartridge = Cartridge.parse(romData)
    val mapper: Mapper = Mapper.create(cart)
    val bus = Bus(mapper)
    val cpu = Cpu(bus)
    val ppu: Ppu get() = bus.ppu
    val apu: Apu get() = bus.apu

    init {
        cpu.reset()
    }

    fun setPad(player: Int, state: Int) {
        bus.pad[player] = state
    }

    /** 執行到下一次垂直空白開始（約 1/60 秒的遊戲時間）。 */
    fun runFrame() {
        val ppu = bus.ppu
        val apu = bus.apu
        ppu.frameDone = false
        while (!ppu.frameDone) {
            val c = cpu.step()
            for (i in 0 until c * 3) ppu.step()
            for (i in 0 until c) apu.step()
        }
    }
}
