package com.example.nesemu.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.KeyEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.nesemu.R
import com.example.nesemu.core.CheatCodec
import com.example.nesemu.core.Pad
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 遊戲畫面。可隨手機旋轉（也可在選單鎖定直向 / 橫向），旋轉不會中斷遊戲。
 * 返回鍵或「選單」鍵開啟選單，選單開啟期間遊戲會暫停。
 */
class EmulatorActivity : Activity() {
    private lateinit var settings: Settings
    private lateinit var gameView: GameView
    private lateinit var controls: ControlsView
    private var runner: EmulatorRunner? = null
    private var keyState = 0
    private var resumed = false
    private var openDialogs = 0

    /** 選單關閉或從背景回來後，遊戲先停著，按任一遊戲按鍵才繼續。 */
    @Volatile
    private var holdForPress = false

    /** 重置遊戲時，對話框關閉後不要再進入「等待按鍵」。 */
    private var skipNextHold = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = Settings(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)

        GameView.aspect = GameView.aspectFor(settings.aspectMode)
        GameView.cropOverscan = settings.cropOverscan
        GameView.aspect = GameView.aspectFor(settings.aspectMode)
        applyOrientation()

        gameView = GameView(this)
        controls = ControlsView(this)
        controls.onAction = { action -> handleAction(action) }
        controls.onPress = { releaseHold() }
        val root = FrameLayout(this)
        val lp = ViewGroup.LayoutParams.MATCH_PARENT
        root.addView(gameView, FrameLayout.LayoutParams(lp, lp))
        root.addView(controls, FrameLayout.LayoutParams(lp, lp))
        setContentView(root)
        hideSystemBars()
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        hideSystemBars()
        if (runner == null && !startRunner()) return
        updatePaused()
    }

    /** 建立並啟動模擬執行緒；沒有 ROM 位址時關閉並回傳 false。 */
    private fun startRunner(): Boolean {
        val uri = intent.data
        if (uri == null) {
            finish()
            return false
        }
        controls.player = 0
        runner = EmulatorRunner(
            this, uri, gameView, settings,
            { keyState or controls.state },
            { msg -> toast(msg) },
            { msg ->
                runOnUiThread {
                    Toast.makeText(this, getString(R.string.error_load, msg), Toast.LENGTH_LONG).show()
                    finish()
                }
            },
        ).also { it.start() }
        return true
    }

    /** 重置遊戲：等同關機再開機（電池存檔會先寫入，即時存檔與金手指保留）。 */
    private fun resetGame() {
        runner?.shutdown()
        runner = null
        holdForPress = false
        controls.holdLabel = false
        skipNextHold = true
        startRunner()
        updatePaused()
        toast("遊戲已重置")
    }

    private fun confirmReset() {
        builder("重置遊戲？")
            .setMessage("遊戲會回到開機狀態，尚未存檔的進度會消失。")
            .setPositiveButton("重置") { _, _ -> resetGame() }
            .setNegativeButton("取消", null)
            .show()
    }

    override fun onPause() {
        if (runner != null) setHold(true)
        resumed = false
        updatePaused()
        super.onPause()
    }

    override fun onDestroy() {
        runner?.shutdown()
        runner = null
        super.onDestroy()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        showMainMenu()
    }

    private fun updatePaused() {
        runner?.paused = !resumed || openDialogs > 0 || holdForPress
    }

    private fun setHold(on: Boolean) {
        holdForPress = on
        runOnUiThread {
            controls.holdLabel = on
            updatePaused()
        }
    }

    private fun releaseHold() {
        if (holdForPress) setHold(false)
    }

    private fun toast(msg: String) {
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    }

    private fun hideSystemBars() {
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private fun applyOrientation() {
        requestedOrientation = when (settings.orientationMode) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        }
    }

    // ---- 功能鍵 ----
    private fun handleAction(action: Int) {
        when (action) {
            ControlsView.ACTION_SAVE -> runner?.saveState(settings.slot)
            ControlsView.ACTION_LOAD -> runner?.loadState(settings.slot)
            ControlsView.ACTION_FAST -> {
                settings.fastForward = !settings.fastForward
                updateFastLabel()
            }
            ControlsView.ACTION_MENU -> showMainMenu()
            ControlsView.ACTION_PLAYER -> {
                val p = 1 - (runner?.player ?: 0)
                runner?.player = p
                controls.player = p
                controls.invalidate()
                toast("目前操作：${p + 1}P")
            }
        }
    }

    private fun updateFastLabel() {
        controls.fastLabel = if (settings.fastForward) "▶▶ ${settings.ffMultiplier}x" else null
    }

    // ---- 對話框工具（開啟期間遊戲暫停） ----
    private fun builder(title: String): AlertDialog.Builder {
        openDialogs++
        updatePaused()
        return AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle(title)
            .setOnDismissListener {
                openDialogs--
                if (openDialogs == 0) {
                    if (skipNextHold) skipNextHold = false else setHold(true)
                }
                updatePaused()
            }
    }

    private fun listDialog(title: String, items: Array<String>, onPick: (Int) -> Unit) {
        builder(title).setItems(items) { _, i -> onPick(i) }.show()
    }

    // ---- 選單 ----
    private fun turboLabel(period: Int) = when (period) {
        2 -> "30 次/秒"
        3 -> "20 次/秒"
        6 -> "10 次/秒"
        else -> "15 次/秒"
    }

    private fun orientationLabel(mode: Int) = when (mode) {
        1 -> "直向"
        2 -> "橫向"
        else -> "自動（感應器）"
    }

    private fun vblankLabel(mode: Int) = when (mode) {
        1 -> "關"
        2 -> "開"
        else -> "自動"
    }

    private fun vblankDialog() {
        listDialog(
            "加長垂直空白",
            arrayOf(
                "自動（只對需要的中文化卡帶開啟）",
                "關（標準 NTSC 時序）",
                "開（加長 100 行，指令選單亂碼或閃爍時請試這項）",
            ),
        ) { i ->
            settings.vblankMode = i
            runner?.applyVblank()
            toast("加長垂直空白：${vblankLabel(i)}")
        }
    }

    private fun aspectLabel(mode: Int) = when (mode) {
        1 -> "原始像素比例"
        2 -> "16:9"
        else -> "4:3"
    }

    private fun showMainMenu() {
        val s = settings
        val items = arrayOf(
            "繼續遊戲",
            "存檔…（快速存檔欄位：${s.slot}）",
            "讀檔…",
            "快轉倍率…（目前 ${s.ffMultiplier}x）",
            "連發速度…（目前 ${turboLabel(s.turboPeriod)}）",
            "金手指…",
            "畫面方向…（目前 ${orientationLabel(s.orientationMode)}）",
            "畫面比例…（目前 ${aspectLabel(s.aspectMode)}）",
            "裁切上下邊緣（目前 ${if (s.cropOverscan) "開" else "關"}）",
            "防閃爍（目前 ${if (s.antiFlicker) "開" else "關"}）",
            "加長垂直空白…（目前 ${vblankLabel(s.vblankMode)}）",
            "重置遊戲…",
            "遊戲資訊（診斷）",
            "回到首頁",
        )
        listDialog("選單", items) { i ->
            when (i) {
                1 -> slotDialog(true)
                2 -> slotDialog(false)
                3 -> speedDialog()
                4 -> turboDialog()
                5 -> showCheats()
                6 -> orientationDialog()
                7 -> aspectDialog()
                8 -> {
                    s.cropOverscan = !s.cropOverscan
                    GameView.cropOverscan = s.cropOverscan
                    GameView.aspect = GameView.aspectFor(s.aspectMode)
                    controls.relayout()
                    toast("上下邊緣裁切：${if (s.cropOverscan) "開" else "關"}")
                }
                9 -> {
                    s.antiFlicker = !s.antiFlicker
                    toast("防閃爍：${if (s.antiFlicker) "開" else "關"}")
                }
                10 -> vblankDialog()
                11 -> confirmReset()
                12 -> showInfo()
                13 -> finish()
            }
        }
    }

    private fun showInfo() {
        val r = runner ?: return
        r.requestInfo { text ->
            runOnUiThread {
                builder("遊戲資訊").setMessage(text)
                    .setPositiveButton("關閉", null)
                    .setNeutralButton("匯出狀態到下載資料夾") { _, _ -> exportState() }
                    .show()
            }
        }
    }

    /** 把目前遊戲狀態存到「下載」資料夾（診斷用，可傳給開發者重現畫面問題）。 */
    private fun exportState() {
        val crc = runner?.romCrc ?: return
        runner?.exportState { bytes ->
            try {
                val name = "nesemu_%08x_%s.sav".format(crc, SimpleDateFormat("MMdd_HHmmss", Locale.getDefault()).format(Date()))
                if (Build.VERSION.SDK_INT >= 29) {
                    val v = android.content.ContentValues().apply {
                        put(android.provider.MediaStore.Downloads.DISPLAY_NAME, name)
                        put(android.provider.MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                    }
                    val uri = contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                        ?: throw IllegalStateException("無法建立檔案")
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                } else {
                    val dir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                    dir.mkdirs()
                    java.io.File(dir, name).writeBytes(bytes)
                }
                runOnUiThread { toast("已匯出到「下載」：$name") }
            } catch (e: Throwable) {
                runOnUiThread { toast("匯出失敗：${e.message}") }
            }
        }
    }

    private fun slotLabels(): Array<String> {
        val crc = runner?.romCrc
        val fmt = SimpleDateFormat("MM/dd HH:mm", Locale.getDefault())
        return Array(4) { i ->
            val f = if (crc != null) StateStore.file(this, crc, i + 1) else null
            "欄位 ${i + 1}　" + if (f != null && f.exists()) fmt.format(Date(f.lastModified())) else "（空）"
        }
    }

    private fun slotDialog(save: Boolean) {
        listDialog(if (save) "存檔到哪個欄位？" else "從哪個欄位讀檔？", slotLabels()) { i ->
            val slot = i + 1
            settings.slot = slot
            if (save) runner?.saveState(slot) else runner?.loadState(slot)
        }
    }

    private fun speedDialog() {
        listDialog("快轉倍率", arrayOf("2 倍", "3 倍", "4 倍")) { i ->
            settings.ffMultiplier = i + 2
            updateFastLabel()
        }
    }

    private fun turboDialog() {
        val periods = intArrayOf(2, 3, 4, 6)
        listDialog("連發速度", Array(4) { turboLabel(periods[it]) }) { i ->
            settings.turboPeriod = periods[i]
        }
    }

    private fun orientationDialog() {
        listDialog("畫面方向", arrayOf("自動（隨手機旋轉）", "鎖定直向", "鎖定橫向")) { i ->
            settings.orientationMode = i
            applyOrientation()
        }
    }

    private fun aspectDialog() {
        listDialog("畫面比例", arrayOf("4:3（電視比例）", "原始像素比例（256:240）", "16:9 寬螢幕")) { i ->
            settings.aspectMode = i
            GameView.aspect = GameView.aspectFor(i)
            controls.relayout()
        }
    }

    // ---- 金手指 ----
    private fun showCheats() {
        val r = runner
        val crc = r?.romCrc
        if (r == null || crc == null) {
            toast("遊戲尚未載入完成")
            return
        }
        val list = CheatStore.load(this, crc)
        val b = builder("金手指")
        if (list.isEmpty()) {
            b.setMessage("尚未新增金手指。\n按「新增」輸入 Game Genie 碼（6 或 8 碼英文字母，例如 GOSSIP）或 RAM 碼（位址:數值，例如 0075:09）。")
        } else {
            val names = Array(list.size) { "${list[it].name}  [${list[it].code}]" }
            val checked = BooleanArray(list.size) { list[it].enabled }
            b.setMultiChoiceItems(names, checked) { _, i, on ->
                list[i].enabled = on
                CheatStore.save(this, crc, list)
                r.applyCheats(list)
            }
            b.setNeutralButton("刪除") { _, _ -> deleteCheatDialog(crc, list) }
        }
        b.setPositiveButton("新增") { _, _ ->
            listDialog("新增方式", arrayOf("手動輸入代碼", "自動尋找（精靈）", "進階記憶體搜尋")) { i ->
                if (i == 0) addCheatDialog(crc, list) else if (i == 1) wizardEntry(crc, list) else searchDialog(crc, list, "請先在遊戲中記下目標數值（如生命數），按「開始新搜尋」。", 0)
            }
        }
        b.setNegativeButton("關閉", null)
        b.show()
    }

    private fun addCheatDialog(crc: Long, list: MutableList<CheatEntry>) {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val nameBox = EditText(this).apply {
            hint = "名稱（可留空）"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine()
        }
        val codeBox = EditText(this).apply {
            hint = "代碼（例如 GOSSIP 或 0075:09）"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine()
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            addView(nameBox)
            addView(codeBox)
        }
        builder("新增金手指")
            .setView(box)
            .setPositiveButton("加入") { _, _ ->
                val code = CheatCodec.normalize(codeBox.text.toString())
                if (CheatCodec.parse(code) == null) {
                    toast("代碼格式不正確")
                } else {
                    val name = nameBox.text.toString().trim().ifEmpty { code }
                    list.add(CheatEntry(code, name, true))
                    CheatStore.save(this, crc, list)
                    runner?.applyCheats(list)
                    toast("已加入並啟用")
                }
                showCheats()
            }
            .setNegativeButton("取消") { _, _ -> showCheats() }
            .show()
    }

    // ---- 自動尋找精靈 ----
    private var wizActive = false
    private var wizName = ""
    private var wizTarget = 99
    private var wizCands: List<Pair<Int, Int>> = emptyList()
    private var wizTrial = -1

    private fun wizReset() {
        wizActive = false
        wizTrial = -1
        wizCands = emptyList()
    }

    private fun numBox(hint: String, text: String = "") = EditText(this).apply {
        this.hint = hint
        setText(text)
        inputType = InputType.TYPE_CLASS_NUMBER
        setSingleLine()
    }

    private fun wizTrialCode() = "%04X:%02X".format(wizCands[wizTrial].first, wizTarget)

    private fun wizardEntry(crc: Long, list: MutableList<CheatEntry>) {
        val pad = (16 * resources.displayMetrics.density).toInt()
        if (wizTrial >= 0 && wizTrial < wizCands.size) {
            val code = wizTrialCode()
            builder("試改 $code")
                .setMessage("剛才把這個位址鎖成 ${wizTarget}，遊戲裡「$wizName」有變成 $wizTarget 嗎？")
                .setPositiveButton("有效，存起來") { _, _ ->
                    list.add(CheatEntry(code, wizName.ifEmpty { code }, true))
                    CheatStore.save(this, crc, list)
                    runner?.applyCheats(list)
                    toast("已加入金手指 $code")
                    wizReset()
                    showCheats()
                }
                .setNegativeButton("沒變，換下一個") { _, _ ->
                    wizTrial++
                    if (wizTrial >= wizCands.size) {
                        runner?.applyCheats(list)
                        toast("候選用完了，請重新搜尋")
                        wizReset()
                    } else {
                        runner?.applyCheats(list + CheatEntry(wizTrialCode(), "試改", true))
                        toast("已試下一個（${wizTrial + 1}/${wizCands.size}），請回遊戲看看，再從 金手指→新增→自動尋找 回報")
                    }
                }
                .setNeutralButton("放棄") { _, _ ->
                    runner?.applyCheats(list)
                    wizReset()
                }
                .show()
            return
        }
        val nameBox = EditText(this).apply { hint = "要改什麼？（如 生命、金錢，可留空）"; setSingleLine() }
        val valBox = numBox(if (wizActive) "現在的新數字（十進位）" else "現在畫面上的數字（十進位）")
        val tgtBox = numBox("想改成多少（預設 99）", if (wizActive) wizTarget.toString() else "")
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            if (!wizActive) addView(nameBox)
            addView(valBox)
            if (!wizActive) addView(tgtBox)
        }
        val b = builder(if (wizActive) "繼續縮小範圍" else "自動尋找金手指")
            .setView(box)
            .setPositiveButton("搜尋") { _, _ ->
                val v = valBox.text.toString().toIntOrNull()
                if (v == null || v !in 0..255) {
                    toast("請輸入 0～255 的數字")
                    wizardEntry(crc, list)
                    return@setPositiveButton
                }
                val first = !wizActive
                if (first) {
                    wizName = nameBox.text.toString().trim()
                    wizTarget = (tgtBox.text.toString().toIntOrNull() ?: 99).coerceIn(0, 255)
                    wizActive = true
                    runner?.memSearch(0, 0) { _, _ -> }
                }
                runner?.memSearch(1, v) { n, found ->
                    runOnUiThread {
                        when {
                            n == 0 -> {
                                toast("沒有符合的位址，請重新開始（數字可能不是直接存放）")
                                wizReset()
                            }
                            n <= 12 -> {
                                wizCands = found
                                wizTrial = 0
                                runner?.applyCheats(list + CheatEntry(wizTrialCode(), "試改", true))
                                toast("剩 $n 個候選，已試第 1 個。請回遊戲看數字有沒有變，再從 金手指→新增→自動尋找 回報")
                            }
                            else -> toast("還有 $n 個候選。請回遊戲讓數字改變，再從 金手指→新增→自動尋找 輸入新數字")
                        }
                    }
                }
            }
            .setNegativeButton("取消", null)
        if (wizActive) b.setNeutralButton("重新開始") { _, _ -> wizReset(); wizardEntry(crc, list) }
        b.show()
    }

    /** 記憶體搜尋：反覆縮小候選位址，找到後存成 RAM 金手指。 */
    private fun searchDialog(crc: Long, list: MutableList<CheatEntry>, status: String, count: Int) {
        val items = arrayOf(
            "開始新搜尋（記錄目前所有數值）",
            "數值等於…（輸入目前畫面上的數字）",
            "數值有變動",
            "數值沒變動",
            "數值變大",
            "數值變小",
            "查看候選結果",
        )
        builder("記憶體搜尋")
            .setTitle("記憶體搜尋　$status")
            .setItems(items) { _, i ->
                when (i) {
                    0, 2, 3, 4, 5 -> runSearch(crc, list, i, 0)
                    1 -> {
                        val box = EditText(this).apply {
                            hint = "目前數值（十進位，如 3）"
                            inputType = InputType.TYPE_CLASS_NUMBER
                            setSingleLine()
                        }
                        builder("數值等於").setView(box)
                            .setPositiveButton("搜尋") { _, _ ->
                                val v = box.text.toString().toIntOrNull()
                                if (v == null || v !in 0..255) {
                                    toast("請輸入 0～255")
                                    searchDialog(crc, list, status, count)
                                } else runSearch(crc, list, 1, v)
                            }
                            .setNegativeButton("取消") { _, _ -> searchDialog(crc, list, status, count) }
                            .show()
                    }
                    else -> runSearch(crc, list, -1, 0)
                }
            }
            .setNegativeButton("回到金手指") { _, _ -> showCheats() }
            .show()
    }

    private fun runSearch(crc: Long, list: MutableList<CheatEntry>, mode: Int, value: Int) {
        // mode -1：只查看結果（以「沒變動」以外的方式不改變候選，這裡用恆真條件）
        runner?.memSearch(if (mode < 0) 6 else mode, value) { n, found ->
            runOnUiThread {
                when {
                    mode == 0 -> searchDialog(crc, list, "已記錄，請回遊戲讓數值改變後再縮小", n)
                    n == 0 -> searchDialog(crc, list, "沒有符合的位址，請重新開始", 0)
                    n <= 40 -> pickCandidate(crc, list, found, n)
                    else -> searchDialog(crc, list, "候選 $n 個，請再縮小範圍", n)
                }
            }
        }
    }

    private fun pickCandidate(crc: Long, list: MutableList<CheatEntry>, found: List<Pair<Int, Int>>, n: Int) {
        val names = Array(found.size) { "%04X  目前值 %d".format(found[it].first, found[it].second) }
        builder("候選 $n 個（點選要鎖定的位址）")
            .setItems(names) { _, i ->
                val (addr, cur) = found[i]
                val box = EditText(this).apply {
                    setText(cur.toString())
                    hint = "鎖定成的數值（十進位 0～255）"
                    inputType = InputType.TYPE_CLASS_NUMBER
                    setSingleLine()
                }
                builder("鎖定 %04X".format(addr)).setView(box)
                    .setPositiveButton("加入") { _, _ ->
                        val v = box.text.toString().toIntOrNull()
                        if (v == null || v !in 0..255) {
                            toast("請輸入 0～255")
                        } else {
                            val code = "%04X:%02X".format(addr, v)
                            list.add(CheatEntry(code, "搜尋 $code", true))
                            CheatStore.save(this, crc, list)
                            runner?.applyCheats(list)
                            toast("已加入並啟用 $code")
                        }
                        showCheats()
                    }
                    .setNegativeButton("取消") { _, _ -> searchDialog(crc, list, "候選 $n 個", n) }
                    .show()
            }
            .setNegativeButton("繼續縮小") { _, _ -> searchDialog(crc, list, "候選 $n 個", n) }
            .show()
    }

    private fun deleteCheatDialog(crc: Long, list: MutableList<CheatEntry>) {
        val names = Array(list.size) { "${list[it].name}  [${list[it].code}]" }
        builder("刪除哪一項？")
            .setItems(names) { _, i ->
                list.removeAt(i)
                CheatStore.save(this, crc, list)
                runner?.applyCheats(list)
                showCheats()
            }
            .setNegativeButton("取消") { _, _ -> showCheats() }
            .show()
    }

    // ---- 實體鍵盤 / 手把 ----
    private fun keyBit(code: Int): Int = when (code) {
        KeyEvent.KEYCODE_DPAD_UP -> Pad.UP
        KeyEvent.KEYCODE_DPAD_DOWN -> Pad.DOWN
        KeyEvent.KEYCODE_DPAD_LEFT -> Pad.LEFT
        KeyEvent.KEYCODE_DPAD_RIGHT -> Pad.RIGHT
        KeyEvent.KEYCODE_X, KeyEvent.KEYCODE_BUTTON_A -> Pad.A
        KeyEvent.KEYCODE_Z, KeyEvent.KEYCODE_BUTTON_B -> Pad.B
        KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_BUTTON_X -> Pad.TURBO_A
        KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_BUTTON_Y -> Pad.TURBO_B
        KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_BUTTON_START -> Pad.START
        KeyEvent.KEYCODE_SHIFT_RIGHT, KeyEvent.KEYCODE_BUTTON_SELECT -> Pad.SELECT
        else -> 0
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val bit = keyBit(keyCode)
        if (bit != 0) {
            keyState = keyState or bit
            releaseHold()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        val bit = keyBit(keyCode)
        if (bit != 0) {
            keyState = keyState and bit.inv()
            return true
        }
        return super.onKeyUp(keyCode, event)
    }
}
