package com.example.nesemu.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.KeyEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.nesemu.R
import com.example.nesemu.core.CheatCodec
import com.example.nesemu.core.Pad
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 遊戲畫面。可隨手機旋轉（也可在選單鎖定直向 / 橫向），旋轉不會中斷遊戲。
 * 返回鍵或「選單」鍵開啟選單，選單開啟期間遊戲會暫停。
 */
class EmulatorActivity : Activity() {
    private lateinit var settings: Settings
    private lateinit var gameView: GameView
    private lateinit var controls: ControlsView
    private var runner: EmulatorRunner? = null
    private var keyState = 0
    private var resumed = false
    private var openDialogs = 0

    /** 選單關閉或從背景回來後，遊戲先停著，按任一遊戲按鍵才繼續。 */
    @Volatile
    private var holdForPress = false

    /** 重置遊戲時，對話框關閉後不要再進入「等待按鍵」。 */
    private var skipNextHold = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = Settings(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)

        GameView.aspect = GameView.aspectFor(settings.aspectMode)
        GameView.cropOverscan = settings.cropOverscan
        GameView.aspect = GameView.aspectFor(settings.aspectMode)
        applyOrientation()

        gameView = GameView(this)
        controls = ControlsView(this)
        controls.onAction = { action -> handleAction(action) }
        controls.onPress = { releaseHold() }
        val root = FrameLayout(this)
        val lp = ViewGroup.LayoutParams.MATCH_PARENT
        root.addView(gameView, FrameLayout.LayoutParams(lp, lp))
        root.addView(controls, FrameLayout.LayoutParams(lp, lp))
        setContentView(root)
        hideSystemBars()
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        hideSystemBars()
        if (runner == null && !startRunner()) return
        updatePaused()
    }

    /** 建立並啟動模擬執行緒；沒有 ROM 位址時關閉並回傳 false。 */
    private fun startRunner(): Boolean {
        val uri = intent.data
        if (uri == null) {
            finish()
            return false
        }
        runner = EmulatorRunner(
            this, uri, gameView, settings,
            { keyState or controls.state },
            { msg -> toast(msg) },
            { msg ->
                runOnUiThread {
                    Toast.makeText(this, getString(R.string.error_load, msg), Toast.LENGTH_LONG).show()
                    finish()
                }
            },
        ).also { it.start() }
        return true
    }

    /** 重置遊戲：等同關機再開機（電池存檔會先寫入，即時存檔與金手指保留）。 */
    private fun resetGame() {
        runner?.shutdown()
        runner = null
        holdForPress = false
        controls.holdLabel = false
        skipNextHold = true
        startRunner()
        updatePaused()
        toast("遊戲已重置")
    }

    private fun confirmReset() {
        builder("重置遊戲？")
            .setMessage("遊戲會回到開機狀態，尚未存檔的進度會消失。")
            .setPositiveButton("重置") { _, _ -> resetGame() }
            .setNegativeButton("取消", null)
            .show()
    }

    override fun onPause() {
        if (runner != null) setHold(true)
        resumed = false
        updatePaused()
        super.onPause()
    }

    override fun onDestroy() {
        runner?.shutdown()
        runner = null
        super.onDestroy()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        showMainMenu()
    }

    private fun updatePaused() {
        runner?.paused = !resumed || openDialogs > 0 || holdForPress
    }

    private fun setHold(on: Boolean) {
        holdForPress = on
        runOnUiThread {
            controls.holdLabel = on
            updatePaused()
        }
    }

    private fun releaseHold() {
        if (holdForPress) setHold(false)
    }

    private fun toast(msg: String) {
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    }

    private fun hideSystemBars() {
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private fun applyOrientation() {
        requestedOrientation = when (settings.orientationMode) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        }
    }

    // ---- 功能鍵 ----
    private fun handleAction(action: Int) {
        when (action) {
            ControlsView.ACTION_SAVE -> runner?.saveState(settings.slot)
            ControlsView.ACTION_LOAD -> runner?.loadState(settings.slot)
            ControlsView.ACTION_FAST -> {
                settings.fastForward = !settings.fastForward
                updateFastLabel()
            }
            ControlsView.ACTION_MENU -> showMainMenu()
        }
    }

    private fun updateFastLabel() {
        controls.fastLabel = if (settings.fastForward) "▶▶ ${settings.ffMultiplier}x" else null
    }

    // ---- 對話框工具（開啟期間遊戲暫停） ----
    private fun builder(title: String): AlertDialog.Builder {
        openDialogs++
        updatePaused()
        return AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle(title)
            .setOnDismissListener {
                openDialogs--
                if (openDialogs == 0) {
                    if (skipNextHold) skipNextHold = false else setHold(true)
                }
                updatePaused()
            }
    }

    private fun listDialog(title: String, items: Array<String>, onPick: (Int) -> Unit) {
        builder(title).setItems(items) { _, i -> onPick(i) }.show()
    }

    // ---- 選單 ----
    private fun turboLabel(period: Int) = when (period) {
        2 -> "30 次/秒"
        3 -> "20 次/秒"
        6 -> "10 次/秒"
        else -> "15 次/秒"
    }

    private fun orientationLabel(mode: Int) = when (mode) {
        1 -> "直向"
        2 -> "橫向"
        else -> "自動（感應器）"
    }

    private fun vblankLabel(mode: Int) = when (mode) {
        1 -> "關"
        2 -> "開"
        else -> "自動"
    }

    private fun vblankDialog() {
        listDialog(
            "加長垂直空白",
            arrayOf(
                "自動（只對需要的中文化卡帶開啟）",
                "關（標準 NTSC 時序）",
                "開（加長 100 行，指令選單亂碼或閃爍時請試這項）",
            ),
        ) { i ->
            settings.vblankMode = i
            runner?.applyVblank()
            toast("加長垂直空白：${vblankLabel(i)}")
        }
    }

    private fun aspectLabel(mode: Int) = when (mode) {
        1 -> "原始像素比例"
        2 -> "16:9"
        else -> "4:3"
    }

    private fun showMainMenu() {
        val s = settings
        val items = arrayOf(
            "繼續遊戲",
            "存檔…（快速存檔欄位：${s.slot}）",
            "讀檔…",
            "快轉倍率…（目前 ${s.ffMultiplier}x）",
            "連發速度…（目前 ${turboLabel(s.turboPeriod)}）",
            "金手指…",
            "畫面方向…（目前 ${orientationLabel(s.orientationMode)}）",
            "畫面比例…（目前 ${aspectLabel(s.aspectMode)}）",
            "裁切上下邊緣（目前 ${if (s.cropOverscan) "開" else "關"}）",
            "加長垂直空白…（目前 ${vblankLabel(s.vblankMode)}）",
            "防閃爍（目前 ${if (s.antiFlicker) "開" else "關"}）",
            "重置遊戲…",
            "遊戲資訊（診斷）",
            "回到首頁",
        )
        listDialog("選單", items) { i ->
            when (i) {
                1 -> slotDialog(true)
                2 -> slotDialog(false)
                3 -> speedDialog()
                4 -> turboDialog()
                5 -> showCheats()
                6 -> orientationDialog()
                7 -> aspectDialog()
                8 -> {
                    s.cropOverscan = !s.cropOverscan
                    GameView.cropOverscan = s.cropOverscan
                    GameView.aspect = GameView.aspectFor(s.aspectMode)
                    controls.relayout()
                    toast("上下邊緣裁切：${if (s.cropOverscan) "開" else "關"}")
                }
                9 -> vblankDialog()
                10 -> {
                    s.antiFlicker = !s.antiFlicker
                    toast("防閃爍：${if (s.antiFlicker) "開" else "關"}")
                }
                11 -> confirmReset()
                12 -> showInfo()
                13 -> finish()
            }
        }
    }

    private fun showInfo() {
        val r = runner ?: return
        r.requestInfo { text ->
            runOnUiThread {
                builder("遊戲資訊").setMessage(text)
                    .setPositiveButton("關閉", null).show()
            }
        }
    }

    private fun slotLabels(): Array<String> {
        val crc = runner?.romCrc
        val fmt = SimpleDateFormat("MM/dd HH:mm", Locale.getDefault())
        return Array(4) { i ->
            val f = if (crc != null) StateStore.file(this, crc, i + 1) else null
            "欄位 ${i + 1}　" + if (f != null && f.exists()) fmt.format(Date(f.lastModified())) else "（空）"
        }
    }

    private fun slotDialog(save: Boolean) {
        listDialog(if (save) "存檔到哪個欄位？" else "從哪個欄位讀檔？", slotLabels()) { i ->
            val slot = i + 1
            settings.slot = slot
            if (save) runner?.saveState(slot) else runner?.loadState(slot)
        }
    }

    private fun speedDialog() {
        listDialog("快轉倍率", arrayOf("2 倍", "3 倍", "4 倍")) { i ->
            settings.ffMultiplier = i + 2
            updateFastLabel()
        }
    }

    private fun turboDialog() {
        val periods = intArrayOf(2, 3, 4, 6)
        listDialog("連發速度", Array(4) { turboLabel(periods[it]) }) { i ->
            settings.turboPeriod = periods[i]
        }
    }

    private fun orientationDialog() {
        listDialog("畫面方向", arrayOf("自動（隨手機旋轉）", "鎖定直向", "鎖定橫向")) { i ->
            settings.orientationMode = i
            applyOrientation()
        }
    }

    private fun aspectDialog() {
        listDialog("畫面比例", arrayOf("4:3（電視比例）", "原始像素比例（256:240）", "16:9 寬螢幕")) { i ->
            settings.aspectMode = i
            GameView.aspect = GameView.aspectFor(i)
            controls.relayout()
        }
    }

    // ---- 金手指 ----
    private fun showCheats() {
        val r = runner
        val crc = r?.romCrc
        if (r == null || crc == null) {
            toast("遊戲尚未載入完成")
            return
        }
        val list = CheatStore.load(this, crc)
        val b = builder("金手指")
        if (list.isEmpty()) {
            b.setMessage("尚未新增金手指。\n按「新增」輸入 Game Genie 碼（6 或 8 碼英文字母，例如 GOSSIP）或 RAM 碼（位址:數值，例如 0075:09）。")
        } else {
            val names = Array(list.size) { "${list[it].name}  [${list[it].code}]" }
            val checked = BooleanArray(list.size) { list[it].enabled }
            b.setMultiChoiceItems(names, checked) { _, i, on ->
                list[i].enabled = on
                CheatStore.save(this, crc, list)
                r.applyCheats(list)
            }
            b.setNeutralButton("刪除") { _, _ -> deleteCheatDialog(crc, list) }
        }
        b.setPositiveButton("新增") { _, _ -> addCheatDialog(crc, list) }
        b.setNegativeButton("關閉", null)
        b.show()
    }

    private fun addCheatDialog(crc: Long, list: MutableList<CheatEntry>) {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val nameBox = EditText(this).apply {
            hint = "名稱（可留空）"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine()
        }
        val codeBox = EditText(this).apply {
            hint = "代碼（例如 GOSSIP 或 0075:09）"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine()
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            addView(nameBox)
            addView(codeBox)
        }
        builder("新增金手指")
            .setView(box)
            .setPositiveButton("加入") { _, _ ->
                val code = CheatCodec.normalize(codeBox.text.toString())
                if (CheatCodec.parse(code) == null) {
                    toast("代碼格式不正確")
                } else {
                    val name = nameBox.text.toString().trim().ifEmpty { code }
                    list.add(CheatEntry(code, name, true))
                    CheatStore.save(this, crc, list)
                    runner?.applyCheats(list)
                    toast("已加入並啟用")
                }
                showCheats()
            }
            .setNegativeButton("取消") { _, _ -> showCheats() }
            .show()
    }

    private fun deleteCheatDialog(crc: Long, list: MutableList<CheatEntry>) {
        val names = Array(list.size) { "${list[it].name}  [${list[it].code}]" }
        builder("刪除哪一項？")
            .setItems(names) { _, i ->
                list.removeAt(i)
                CheatStore.save(this, crc, list)
                runner?.applyCheats(list)
                showCheats()
            }
            .setNegativeButton("取消") { _, _ -> showCheats() }
            .show()
    }

    // ---- 實體鍵盤 / 手把 ----
    private fun keyBit(code: Int): Int = when (code) {
        KeyEvent.KEYCODE_DPAD_UP -> Pad.UP
        KeyEvent.KEYCODE_DPAD_DOWN -> Pad.DOWN
        KeyEvent.KEYCODE_DPAD_LEFT -> Pad.LEFT
        KeyEvent.KEYCODE_DPAD_RIGHT -> Pad.RIGHT
        KeyEvent.KEYCODE_X, KeyEvent.KEYCODE_BUTTON_A -> Pad.A
        KeyEvent.KEYCODE_Z, KeyEvent.KEYCODE_BUTTON_B -> Pad.B
        KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_BUTTON_X -> Pad.TURBO_A
        KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_BUTTON_Y -> Pad.TURBO_B
        KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_BUTTON_START -> Pad.START
        KeyEvent.KEYCODE_SHIFT_RIGHT, KeyEvent.KEYCODE_BUTTON_SELECT -> Pad.SELECT
        else -> 0
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val bit = keyBit(keyCode)
        if (bit != 0) {
            keyState = keyState or bit
            releaseHold()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        val bit = keyBit(keyCode)
        if (bit != 0) {
            keyState = keyState and bit.inv()
            return true
        }
        return super.onKeyUp(keyCode, event)
    }
}
