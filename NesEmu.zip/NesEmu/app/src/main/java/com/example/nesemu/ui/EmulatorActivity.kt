package com.example.nesemu.ui

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.nesemu.R
import com.example.nesemu.core.Pad

/** 遊戲畫面。可隨手機旋轉（直向 / 橫向），旋轉時不會中斷遊戲。 */
class EmulatorActivity : Activity() {
    private lateinit var gameView: GameView
    private lateinit var controls: ControlsView
    private var runner: EmulatorRunner? = null
    private var keyState = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)

        gameView = GameView(this)
        controls = ControlsView(this)
        val root = FrameLayout(this)
        val lp = ViewGroup.LayoutParams.MATCH_PARENT
        root.addView(gameView, FrameLayout.LayoutParams(lp, lp))
        root.addView(controls, FrameLayout.LayoutParams(lp, lp))
        setContentView(root)
        hideSystemBars()
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
        val r = runner
        if (r == null) {
            val uri = intent.data
            if (uri == null) {
                finish()
                return
            }
            runner = EmulatorRunner(this, uri, gameView, { keyState or controls.state }) { msg ->
                runOnUiThread {
                    Toast.makeText(this, getString(R.string.error_load, msg), Toast.LENGTH_LONG).show()
                    finish()
                }
            }.also { it.start() }
        } else {
            r.paused = false
        }
    }

    override fun onPause() {
        runner?.paused = true
        super.onPause()
    }

    override fun onDestroy() {
        runner?.shutdown()
        runner = null
        super.onDestroy()
    }

    private fun hideSystemBars() {
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private fun keyBit(code: Int): Int = when (code) {
        KeyEvent.KEYCODE_DPAD_UP -> Pad.UP
        KeyEvent.KEYCODE_DPAD_DOWN -> Pad.DOWN
        KeyEvent.KEYCODE_DPAD_LEFT -> Pad.LEFT
        KeyEvent.KEYCODE_DPAD_RIGHT -> Pad.RIGHT
        KeyEvent.KEYCODE_X, KeyEvent.KEYCODE_BUTTON_A -> Pad.A
        KeyEvent.KEYCODE_Z, KeyEvent.KEYCODE_BUTTON_B -> Pad.B
        KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_BUTTON_START -> Pad.START
        KeyEvent.KEYCODE_SHIFT_RIGHT, KeyEvent.KEYCODE_BUTTON_SELECT -> Pad.SELECT
        else -> 0
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val bit = keyBit(keyCode)
        if (bit != 0) {
            keyState = keyState or bit
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        val bit = keyBit(keyCode)
        if (bit != 0) {
            keyState = keyState and bit.inv()
            return true
        }
        return super.onKeyUp(keyCode, event)
    }
}
