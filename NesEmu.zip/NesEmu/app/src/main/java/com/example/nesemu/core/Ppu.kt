package com.example.nesemu.core

import java.io.DataInputStream
import java.io.DataOutputStream

private val NES_PALETTE = intArrayOf(
    0x666666, 0x002A88, 0x1412A7, 0x3B00A4, 0x5C007E, 0x6E0040, 0x6C0600, 0x561D00,
    0x333500, 0x0B4800, 0x005200, 0x004F08, 0x00404D, 0x000000, 0x000000, 0x000000,
    0xADADAD, 0x155FD9, 0x4240FF, 0x7527FE, 0xA01ACC, 0xB71E7B, 0xB53120, 0x994E00,
    0x6B6D00, 0x388700, 0x0C9300, 0x008F32, 0x007C8D, 0x000000, 0x000000, 0x000000,
    0xFFFEFF, 0x64B0FF, 0x9290FF, 0xC676FF, 0xF36AFF, 0xFE6ECC, 0xFE8170, 0xEA9E22,
    0xBCBE00, 0x88D800, 0x5CE430, 0x45E082, 0x48CDDE, 0x4F4F4F, 0x000000, 0x000000,
    0xFFFEFF, 0xC0DFFF, 0xD3D2FF, 0xE8C8FF, 0xFBC2FF, 0xFEC4EA, 0xFECCC5, 0xF7D8A5,
    0xE4E594, 0xCFEF96, 0xBDF4AB, 0xB3F3CC, 0xB5EBF2, 0xB8B8B8, 0x000000, 0x000000,
).map { it or (0xFF shl 24) }.toIntArray()

/** 逐週期 PPU。每次 step() 前進一個 PPU 週期；frame 為 256x240 的 ARGB 畫面。 */
class Ppu(private val mapper: Mapper) {
    val frame = IntArray(256 * 240)
    val oam = IntArray(256)
    private val vram = IntArray(4096)
    private val palette = IntArray(32)

    var ctrl = 0
    var mask = 0
    var status = 0
    var oamAddr = 0
    private var v = 0

    /**
     * $2007 專用的位址。真實硬體中它和渲染用的 v 是同一個暫存器，渲染中寫 $2007 會寫到被
     * 渲染過程改動的位址；但部分中文化遊戲會在渲染中大量寫入 CHR-RAM，需要相容簡易模擬器的做法：
     * 渲染中 $2007 使用獨立位址，不受渲染影響。非渲染時與 v 保持同步。
     */
    private var pv = 0

    private fun renderingActive() = (mask and 0x18) != 0 && scanline < 240
    private var t = 0
    private var fineX = 0
    private var w = false
    private var readBuf = 0

    var scanline = -1
    var cycle = 0

    // 非渲染期間由 $2006/$2007 造成的 A12 變化（MMC3 計數器用）
    private var dot = 0L
    private var a12 = false
    private var a12Fell = 0L

    private fun portA12(addr: Int) {
        if ((mask and 0x18) != 0 && scanline < 240) return // 渲染中由固定取圖時序處理
        val high = (addr and 0x1000) != 0
        if (high && !a12) {
            if (dot - a12Fell >= 9) mapper.scanline()
        } else if (!high && a12) {
            a12Fell = dot
        }
        a12 = high
    }
    private var odd = false
    var frameDone = false
    var nmi = false

    // 背景
    private var ntByte = 0
    private var atByte = 0
    private var tileLo = 0
    private var tileHi = 0
    private var shLo = 0
    private var shHi = 0
    private var shAtLo = 0
    private var shAtHi = 0

    // 精靈（下一條掃描線）
    private val spX = IntArray(8)
    private val spAttr = IntArray(8)
    private val spLo = IntArray(8)
    private val spHi = IntArray(8)
    private var spCount = 0
    private var spZero = false

    // ---- 即時存檔 ----
    fun save(o: DataOutputStream) {
        o.writeInts(oam)
        o.writeInts(vram)
        o.writeInts(palette)
        o.writeInts(spX)
        o.writeInts(spAttr)
        o.writeInts(spLo)
        o.writeInts(spHi)
        o.writeInts(
            intArrayOf(
                ctrl, mask, status, oamAddr, v, t, fineX, readBuf, scanline, cycle,
                ntByte, atByte, tileLo, tileHi, shLo, shHi, shAtLo, shAtHi, spCount,
            )
        )
        o.writeBoolean(w)
        o.writeBoolean(odd)
        o.writeBoolean(nmi)
        o.writeBoolean(spZero)
    }

    fun load(i: DataInputStream) {
        i.readInts(oam)
        i.readInts(vram)
        i.readInts(palette)
        i.readInts(spX)
        i.readInts(spAttr)
        i.readInts(spLo)
        i.readInts(spHi)
        val s = IntArray(19)
        i.readInts(s)
        ctrl = s[0]; mask = s[1]; status = s[2]; oamAddr = s[3]; v = s[4]; pv = v; t = s[5]
        fineX = s[6]; readBuf = s[7]; scanline = s[8]; cycle = s[9]
        ntByte = s[10]; atByte = s[11]; tileLo = s[12]; tileHi = s[13]
        shLo = s[14]; shHi = s[15]; shAtLo = s[16]; shAtHi = s[17]; spCount = s[18]
        w = i.readBoolean()
        odd = i.readBoolean()
        nmi = i.readBoolean()
        spZero = i.readBoolean()
        frameDone = false
    }

    // ---- 暫存器 ----
    fun readReg(r: Int): Int {
        when (r) {
            2 -> {
                val s = (status and 0xE0) or (readBuf and 0x1F)
                status = status and 0x7F
                w = false
                return s
            }
            4 -> return oam[oamAddr]
            7 -> {
                val a = pv and 0x3FFF
                portA12(a)
                val d: Int
                if (a >= 0x3F00) {
                    d = vramRead(a)
                    readBuf = vramRead(a - 0x1000)
                } else {
                    d = readBuf
                    readBuf = vramRead(a)
                }
                pv = (pv + (if ((ctrl and 0x04) != 0) 32 else 1)) and 0x7FFF
                if (!renderingActive()) v = pv
                portA12(pv)
                return d
            }
        }
        return 0
    }

    fun writeReg(r: Int, d: Int) {
        when (r) {
            0 -> {
                val old = ctrl
                ctrl = d
                t = (t and 0x0C00.inv()) or ((d and 3) shl 10)
                if ((old and 0x80) == 0 && (d and 0x80) != 0 && (status and 0x80) != 0) nmi = true
            }
            1 -> mask = d
            3 -> oamAddr = d
            4 -> {
                oam[oamAddr] = d
                oamAddr = (oamAddr + 1) and 0xFF
            }
            5 -> {
                if (!w) {
                    fineX = d and 7
                    t = (t and 0x001F.inv()) or (d shr 3)
                } else {
                    t = (t and 0x73E0.inv()) or ((d and 7) shl 12) or ((d shr 3) shl 5)
                }
                w = !w
            }
            6 -> {
                if (!w) {
                    t = (t and 0x00FF) or ((d and 0x3F) shl 8)
                } else {
                    t = (t and 0xFF00) or d
                    v = t
                    pv = t
                    portA12(v)
                }
                w = !w
            }
            7 -> {
                portA12(pv)
                vramWrite(pv and 0x3FFF, d)
                pv = (pv + (if ((ctrl and 0x04) != 0) 32 else 1)) and 0x7FFF
                if (!renderingActive()) v = pv
                portA12(pv)
            }
        }
    }

    // ---- 記憶體 ----
    private fun paletteIndex(addr: Int): Int {
        var i = addr and 0x1F
        if ((i and 0x13) == 0x10) i = i and 0x0F
        return i
    }

    private fun vramRead(address: Int): Int {
        val addr = address and 0x3FFF
        return when {
            addr < 0x2000 -> mapper.ppuRead(addr)
            addr < 0x3F00 -> vram[mapper.ntIndex(addr)]
            else -> palette[paletteIndex(addr)]
        }
    }

    private fun vramWrite(addr: Int, d: Int) {
        when {
            addr < 0x2000 -> mapper.ppuWrite(addr, d)
            addr < 0x3F00 -> vram[mapper.ntIndex(addr)] = d
            else -> palette[paletteIndex(addr)] = d and 0x3F
        }
    }

    // ---- 捲動輔助 ----
    private fun incX() {
        if ((v and 0x1F) == 31) {
            v = (v and 0x1F.inv()) xor 0x0400
        } else {
            v++
        }
    }

    private fun incY() {
        if ((v and 0x7000) != 0x7000) {
            v += 0x1000
        } else {
            v = v and 0x7000.inv()
            var y = (v and 0x03E0) shr 5
            if (y == 29) {
                y = 0
                v = v xor 0x0800
            } else if (y == 31) {
                y = 0
            } else {
                y++
            }
            v = (v and 0x03E0.inv()) or (y shl 5)
        }
    }

    private fun loadShifters() {
        shLo = (shLo and 0xFF00) or tileLo
        shHi = (shHi and 0xFF00) or tileHi
        shAtLo = (shAtLo and 0xFF00) or (if ((atByte and 1) != 0) 0xFF else 0)
        shAtHi = (shAtHi and 0xFF00) or (if ((atByte and 2) != 0) 0xFF else 0)
    }

    // ---- 主迴圈：前進一個 PPU 週期 ----
    fun step() {
        dot++
        val line = scanline
        val renderOn = (mask and 0x18) != 0
        if (line == 0 && cycle == 0 && odd && renderOn) cycle = 1
        val cyc = cycle

        if (line < 240) {
            if (line == -1 && cyc == 1) status = status and 0x1F
            if (renderOn) {
                if (cyc in 2..257 || cyc in 321..337) {
                    if ((mask and 0x08) != 0) {
                        shLo = (shLo shl 1) and 0xFFFF
                        shHi = (shHi shl 1) and 0xFFFF
                        shAtLo = (shAtLo shl 1) and 0xFFFF
                        shAtHi = (shAtHi shl 1) and 0xFFFF
                    }
                    when ((cyc - 1) and 7) {
                        0 -> {
                            loadShifters()
                            ntByte = vramRead(0x2000 or (v and 0x0FFF))
                        }
                        2 -> {
                            var a = vramRead(
                                0x23C0 or (v and 0x0C00) or ((v shr 4) and 0x38) or ((v shr 2) and 0x07)
                            )
                            if ((v and 0x40) != 0) a = a shr 4
                            if ((v and 0x02) != 0) a = a shr 2
                            atByte = a and 3
                        }
                        4 -> tileLo = vramRead(
                            ((ctrl and 0x10) shl 8) + (ntByte shl 4) + ((v shr 12) and 7)
                        )
                        6 -> tileHi = vramRead(
                            ((ctrl and 0x10) shl 8) + (ntByte shl 4) + ((v shr 12) and 7) + 8
                        )
                        7 -> incX()
                    }
                }
                if (cyc == 256) incY()
                if (cyc == 257) {
                    loadShifters()
                    v = (v and 0x041F.inv()) or (t and 0x041F)
                    evalSprites(line + 1)
                }
                if (line == -1 && cyc in 280..304) {
                    v = (v and 0x7BE0.inv()) or (t and 0x7BE0)
                }
                // MMC3 以 A12 由低變高計數：背景在 $1000、精靈在 $0000 時，
                // 上升緣出現在下一行預取（約第 325 點），否則在精靈取圖樣時（約第 261 點）
                val edge = if ((ctrl and 0x30) == 0x10) 325 else 261
                if (cyc == edge) mapper.scanline()
            }
            if (line >= 0 && cyc in 1..256) renderPixel(cyc - 1, line)
        } else if (line == 241 && cyc == 1) {
            status = status or 0x80
            if ((ctrl and 0x80) != 0) nmi = true
            frameDone = true
        }

        cycle++
        if (cycle > 340) {
            cycle = 0
            scanline++
            if (scanline > 260) {
                scanline = -1
                odd = !odd
            }
        }
    }

    private fun evalSprites(target: Int) {
        spCount = 0
        spZero = false
        if (target > 239) return
        val h = if ((ctrl and 0x20) != 0) 16 else 8
        for (n in 0 until 64) {
            val y = oam[n * 4]
            val row = target - y - 1
            if (row < 0 || row >= h) continue
            if (spCount >= 8) {
                status = status or 0x20
                break
            }
            val tile = oam[n * 4 + 1]
            val attr = oam[n * 4 + 2]
            var r = row
            if ((attr and 0x80) != 0) r = h - 1 - r
            val addr = if (h == 8) {
                ((ctrl and 0x08) shl 9) + tile * 16 + r
            } else {
                var tt = tile and 0xFE
                if (r >= 8) {
                    tt++
                    r -= 8
                }
                ((tile and 1) shl 12) + tt * 16 + r
            }
            var lo = vramRead(addr)
            var hi = vramRead(addr + 8)
            if ((attr and 0x40) != 0) {
                lo = Integer.reverse(lo) ushr 24
                hi = Integer.reverse(hi) ushr 24
            }
            spX[spCount] = oam[n * 4 + 3]
            spAttr[spCount] = attr
            spLo[spCount] = lo
            spHi[spCount] = hi
            if (n == 0) spZero = true
            spCount++
        }
    }

    private fun renderPixel(x: Int, y: Int) {
        var bgPix = 0
        var bgPal = 0
        if ((mask and 0x08) != 0 && (x >= 8 || (mask and 0x02) != 0)) {
            val bit = 0x8000 shr fineX
            bgPix = (if ((shHi and bit) != 0) 2 else 0) or (if ((shLo and bit) != 0) 1 else 0)
            bgPal = (if ((shAtHi and bit) != 0) 2 else 0) or (if ((shAtLo and bit) != 0) 1 else 0)
        }

        var fgPix = 0
        var fgPal = 0
        var fgBehind = false
        var fgIsZero = false
        if ((mask and 0x10) != 0 && (x >= 8 || (mask and 0x04) != 0)) {
            for (i in 0 until spCount) {
                val dx = x - spX[i]
                if (dx in 0..7) {
                    val b = 7 - dx
                    val p = (((spHi[i] shr b) and 1) shl 1) or ((spLo[i] shr b) and 1)
                    if (p != 0) {
                        fgPix = p
                        fgPal = (spAttr[i] and 3) + 4
                        fgBehind = (spAttr[i] and 0x20) != 0
                        fgIsZero = i == 0 && spZero
                        break
                    }
                }
            }
        }

        var pix = 0
        var pal = 0
        if (bgPix == 0 && fgPix != 0) {
            pix = fgPix; pal = fgPal
        } else if (bgPix != 0 && fgPix == 0) {
            pix = bgPix; pal = bgPal
        } else if (bgPix != 0) {
            if (fgBehind) {
                pix = bgPix; pal = bgPal
            } else {
                pix = fgPix; pal = fgPal
            }
            if (fgIsZero && x != 255 && (mask and 0x18) == 0x18) status = status or 0x40
        }

        val idx = if (pix == 0) 0 else (pal shl 2) or pix
        val c = palette[paletteIndex(idx)] and (if ((mask and 1) != 0) 0x30 else 0x3F)
        frame[y * 256 + x] = NES_PALETTE[c]
    }
}
