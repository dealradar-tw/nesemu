package com.example.nesemu.core

enum class Mirror { HORIZONTAL, VERTICAL, SINGLE0, SINGLE1, FOUR }

class RomException(message: String) : Exception(message)

/** 解析後的 iNES 卡帶資料。 */
class Cartridge(
    val prg: ByteArray,
    val chr: ByteArray,
    val chrIsRam: Boolean,
    val mapperId: Int,
    val mirror: Mirror,
    val hasBattery: Boolean,
) {
    companion object {
        fun parse(data: ByteArray): Cartridge {
            if (data.size < 16 ||
                data[0] != 'N'.code.toByte() || data[1] != 'E'.code.toByte() ||
                data[2] != 'S'.code.toByte() || data[3] != 0x1A.toByte()
            ) {
                throw RomException("不是有效的 iNES（.nes）檔案")
            }
            val prgBanks = data[4].toInt() and 0xFF
            val chrBanks = data[5].toInt() and 0xFF
            val f6 = data[6].toInt() and 0xFF
            val f7 = data[7].toInt() and 0xFF
            val mapper = (f7 and 0xF0) or (f6 shr 4)
            val hasTrainer = (f6 and 0x04) != 0
            var off = 16 + (if (hasTrainer) 512 else 0)
            val prgSize = prgBanks * 16384
            val chrSize = chrBanks * 8192
            if (prgBanks == 0 || data.size < off + prgSize + chrSize) {
                throw RomException("ROM 檔案大小不正確或已損毀")
            }
            val prg = data.copyOfRange(off, off + prgSize)
            off += prgSize
            val chrIsRam = chrBanks == 0
            val chr = if (chrIsRam) ByteArray(8192) else data.copyOfRange(off, off + chrSize)
            val mirror = when {
                (f6 and 0x08) != 0 -> Mirror.FOUR
                (f6 and 0x01) != 0 -> Mirror.VERTICAL
                else -> Mirror.HORIZONTAL
            }
            return Cartridge(prg, chr, chrIsRam, mapper, mirror, (f6 and 0x02) != 0)
        }
    }
}
