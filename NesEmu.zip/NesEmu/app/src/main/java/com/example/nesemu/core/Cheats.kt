package com.example.nesemu.core

/** 解碼後的金手指補丁。 */
sealed class CheatPatch {
    /** Game Genie：讀取 ROM 位址時替換數值（compare < 0 代表 6 碼，不比對）。 */
    class Rom(val addr: Int, val value: Int, val compare: Int) : CheatPatch()

    /** RAM 碼：每一格把數值寫入 CPU 位址（$0000-$07FF 或 $6000-$7FFF）。 */
    class Ram(val addr: Int, val value: Int) : CheatPatch()
}

object CheatCodec {
    private const val GG_LETTERS = "APZLGITYEOXUKSVN"
    private val RAW = Regex("^([0-9A-F]{1,4}):([0-9A-F]{1,2})$")

    fun normalize(code: String): String =
        code.trim().uppercase().replace(" ", "").replace("-", "")

    /** 支援 Game Genie（6 或 8 碼字母）與 RAM 碼（例如 0075:09）。格式錯誤回傳 null。 */
    fun parse(code: String): CheatPatch? {
        val c = normalize(code)
        val raw = RAW.matchEntire(c)
        if (raw != null) {
            val addr = raw.groupValues[1].toInt(16)
            val value = raw.groupValues[2].toInt(16)
            return if (addr < 0x800 || addr in 0x6000..0x7FFF) CheatPatch.Ram(addr, value) else null
        }
        if (c.length != 6 && c.length != 8) return null
        val n = IntArray(c.length)
        for (k in c.indices) {
            val d = GG_LETTERS.indexOf(c[k])
            if (d < 0) return null
            n[k] = d
        }
        val addr = 0x8000 + (
            ((n[3] and 7) shl 12) or ((n[5] and 7) shl 8) or ((n[4] and 8) shl 8) or
                ((n[2] and 7) shl 4) or ((n[1] and 8) shl 4) or (n[4] and 7) or (n[3] and 8)
            )
        return if (c.length == 6) {
            val v = ((n[1] and 7) shl 4) or ((n[0] and 8) shl 4) or (n[0] and 7) or (n[5] and 8)
            CheatPatch.Rom(addr, v, -1)
        } else {
            val v = ((n[1] and 7) shl 4) or ((n[0] and 8) shl 4) or (n[0] and 7) or (n[7] and 8)
            val cmp = ((n[7] and 7) shl 4) or ((n[6] and 8) shl 4) or (n[6] and 7) or (n[5] and 8)
            CheatPatch.Rom(addr, v, cmp)
        }
    }
}
