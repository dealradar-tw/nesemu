package com.example.nesemu.ui

import android.content.Context
import android.graphics.Bitmap
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import com.example.nesemu.core.Nes
import java.io.File
import java.util.zip.CRC32

/**
 * 模擬執行緒：載入 ROM、逐格執行、輸出畫面與音訊、管理電池存檔（SRAM）。
 * 有音訊時以 AudioTrack 的阻塞寫入來控制速度，否則用計時器限制在約 60 FPS。
 */
class EmulatorRunner(
    private val context: Context,
    private val uri: Uri,
    private val gameView: GameView,
    private val input: () -> Int,
    private val onError: (String) -> Unit,
) : Thread("nes-emulator") {

    @Volatile
    private var running = true

    @Volatile
    var paused = false

    fun shutdown() {
        running = false
        try {
            join(2000)
        } catch (_: InterruptedException) {
        }
    }

    override fun run() {
        val nes: Nes
        val crc: Long
        try {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalStateException("無法讀取檔案")
            nes = Nes(bytes)
            crc = CRC32().also { it.update(bytes) }.value
        } catch (e: Throwable) {
            onError(e.message ?: e.toString())
            return
        }

        val sramFile = File(File(context.filesDir, "sram").also { it.mkdirs() }, "%08x.sav".format(crc))
        if (nes.cart.hasBattery) loadSram(nes, sramFile)

        val bitmap = Bitmap.createBitmap(256, 240, Bitmap.Config.ARGB_8888)
        val track = createTrack()
        track?.play()

        val frameNanos = 16_639_267L // 1e9 / 60.0988
        var next = System.nanoTime()
        var lastPaused = false
        var framesSinceSave = 0

        while (running) {
            if (paused) {
                if (!lastPaused) {
                    track?.pause()
                    lastPaused = true
                }
                sleep(30)
                next = System.nanoTime()
                continue
            }
            if (lastPaused) {
                track?.play()
                lastPaused = false
            }

            nes.setPad(0, input())
            nes.runFrame()
            bitmap.setPixels(nes.ppu.frame, 0, 256, 0, 0, 256, 240)
            gameView.drawFrame(bitmap)

            val apu = nes.apu
            var audioOk = false
            if (track != null && apu.sampleCount > 0) {
                audioOk = track.write(apu.samples, 0, apu.sampleCount) >= 0
            }
            apu.sampleCount = 0

            if (!audioOk) {
                next += frameNanos
                val wait = next - System.nanoTime()
                if (wait > 0) {
                    sleep(wait / 1_000_000L, (wait % 1_000_000L).toInt())
                } else if (wait < -frameNanos * 5) {
                    next = System.nanoTime()
                }
            }

            if (nes.cart.hasBattery && ++framesSinceSave >= 60 * 30) {
                framesSinceSave = 0
                saveSram(nes, sramFile)
            }
        }

        try {
            track?.stop()
            track?.release()
        } catch (_: Throwable) {
        }
        if (nes.cart.hasBattery) saveSram(nes, sramFile)
    }

    private fun createTrack(): AudioTrack? = try {
        val rate = 44100
        val minBuf = AudioTrack.getMinBufferSize(
            rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuf, 8192))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
    } catch (_: Throwable) {
        null
    }

    private fun loadSram(nes: Nes, file: File) {
        try {
            if (file.exists()) {
                val data = file.readBytes()
                System.arraycopy(data, 0, nes.mapper.prgRam, 0, minOf(data.size, nes.mapper.prgRam.size))
            }
        } catch (_: Throwable) {
        }
    }

    private fun saveSram(nes: Nes, file: File) {
        try {
            file.writeBytes(nes.mapper.prgRam)
        } catch (_: Throwable) {
        }
    }
}
