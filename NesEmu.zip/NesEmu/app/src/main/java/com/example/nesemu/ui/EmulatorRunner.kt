package com.example.nesemu.ui

import android.content.Context
import android.graphics.Bitmap
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import com.example.nesemu.core.CheatCodec
import com.example.nesemu.core.Nes
import com.example.nesemu.core.Pad
import java.io.File
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.zip.CRC32

/**
 * 模擬執行緒：載入 ROM、逐格執行、輸出畫面與音訊，並處理連發、快轉、
 * 即時存讀檔、金手指與電池存檔（SRAM）。
 *
 * 一般速度時以 AudioTrack 的阻塞寫入控制節奏；快轉或沒有音訊時用計時器限制在約 60 FPS。
 * 會動到模擬器狀態的操作都經由 post() 排進佇列，由本執行緒執行，避免執行緒競爭。
 */
class EmulatorRunner(
    private val context: Context,
    private val uri: Uri,
    private val gameView: GameView,
    private val settings: Settings,
    private val input: () -> Int,
    private val onMessage: (String) -> Unit,
    private val onError: (String) -> Unit,
) : Thread("nes-emulator") {

    @Volatile
    private var running = true

    @Volatile
    var paused = false

    /** 目前由觸控操作的玩家（0 = 1P，1 = 2P）。 */
    @Volatile
    var player = 0

    /** ROM 載入完成後才會有值（用來區分不同遊戲的存檔與金手指）。 */
    @Volatile
    var romCrc: Long? = null

    private val tasks = ConcurrentLinkedQueue<(Nes) -> Unit>()
    private var frameCounter = 0

    /** 倒轉用的快照：每 3 幀存一次，最多保留約 15 秒。 */
    private val rewindBuf = java.util.ArrayDeque<ByteArray>()

    fun post(task: (Nes) -> Unit) {
        tasks.add(task)
    }

    fun saveState(slot: Int) = post { nes ->
        val crc = romCrc ?: return@post
        try {
            StateStore.file(context, crc, slot).writeBytes(nes.saveState())
            onMessage("已存檔（欄位 $slot）")
        } catch (e: Throwable) {
            onMessage("存檔失敗：${e.message}")
        }
    }

    fun loadState(slot: Int) = post { nes ->
        val crc = romCrc ?: return@post
        val f = StateStore.file(context, crc, slot)
        if (!f.exists()) {
            onMessage("欄位 $slot 沒有存檔")
            return@post
        }
        try {
            nes.loadState(f.readBytes())
            rewindBuf.clear()
            onMessage("已讀檔（欄位 $slot）")
        } catch (e: Throwable) {
            onMessage("讀檔失敗：${e.message}")
        }
    }

    /** 取得目前遊戲狀態的位元組（診斷匯出用）。 */
    fun exportState(cb: (ByteArray) -> Unit) = post { nes -> cb(nes.saveState()) }

    // ---- 記憶體搜尋（金手指自動尋找） ----
    private val cand = BooleanArray(2048)
    private val prev = IntArray(2048)
    private var searching = false

    /**
     * mode：0 開始新搜尋、1 等於 value、2 有變動、3 沒變動、4 增加、5 減少。
     * 回呼（count, 最多 40 筆的「位址 to 目前值」）在模擬執行緒上呼叫。
     */
    fun memSearch(mode: Int, value: Int, cb: (Int, List<Pair<Int, Int>>) -> Unit) = post { nes ->
        if (mode == 0 || !searching) {
            for (i in 0 until 2048) { cand[i] = true; prev[i] = nes.peekRam(i) }
            searching = true
        }
        if (mode != 0) {
            for (i in 0 until 2048) {
                if (!cand[i]) continue
                val c = nes.peekRam(i)
                val p = prev[i]
                cand[i] = when (mode) {
                    1 -> c == value
                    2 -> c != p
                    3 -> c == p
                    4 -> c > p
                    5 -> c < p
                    else -> true
                }
            }
            for (i in 0 until 2048) prev[i] = nes.peekRam(i)
        }
        var n = 0
        val out = ArrayList<Pair<Int, Int>>()
        for (i in 0 until 2048) if (cand[i]) { n++; if (out.size < 40) out.add(i to nes.peekRam(i)) }
        cb(n, out)
    }

    /** 套用金手指清單（只會啟用 enabled 的項目）。 */
    fun applyCheats(list: List<CheatEntry>) {
        val codes = list.filter { it.enabled }.map { it.code }
        post { nes -> nes.setCheats(codes.mapNotNull { CheatCodec.parse(it) }) }
    }

    /** 診斷資訊：在模擬執行緒上產生文字，完成後回呼。 */
    fun requestInfo(cb: (String) -> Unit) = post { nes ->
        val c = nes.cart
        val cpu = nes.cpu
        val sb = StringBuilder()
        sb.append("Mapper：${c.mapperId}（${nes.mapper.javaClass.simpleName}）\n")
        sb.append("PRG：${c.prg.size / 1024} KB　CHR：${if (c.chrIsRam) "RAM" else "${c.chr.size / 1024} KB"}\n")
        sb.append("鏡像：${c.mirror}　電池：${if (c.hasBattery) "有" else "無"}\n")
        sb.append("CRC32：%08X\n".format(romCrc ?: 0L))
        sb.append("PC：%04X　掃描線：${nes.ppu.scanline}\n".format(cpu.pc))
        sb.append("PPU 遮罩：%02X　控制：%02X\n".format(nes.ppu.mask, nes.ppu.ctrl))
        sb.append("卡帶暫存器寫入：${nes.mapper.regWrites} 次\n")
        sb.append("未支援指令：${cpu.unknownCount} 次")
        if (cpu.unknownCount > 0) sb.append("（最後 %02X @ %04X）".format(cpu.lastUnknownOp, cpu.lastUnknownPc))
        cb(sb.toString())
    }

    /** 依設定套用「加長垂直空白」（在模擬執行緒上執行）。 */
    fun applyVblank() = post { nes ->
        nes.ppu.extraLines = when (settings.vblankMode) {
            1 -> 0
            2 -> 100
            else -> nes.autoExtraLines()
        }
    }

    fun shutdown() {
        running = false
        try {
            join(2000)
        } catch (_: InterruptedException) {
        }
    }

    /** 把按鍵狀態轉成送進模擬器的 8 位元；連發位元依設定的頻率切換 A / B。 */
    private fun effectiveInput(): Int {
        val raw = input()
        var s = raw and 0xFF
        val period = settings.turboPeriod
        val on = (frameCounter % period) < maxOf(1, period / 2)
        if ((raw and Pad.TURBO_A) != 0) s = if (on) s or Pad.A else s and Pad.A.inv()
        if ((raw and Pad.TURBO_B) != 0) s = if (on) s or Pad.B else s and Pad.B.inv()
        return s
    }

    override fun run() {
        val nes: Nes
        val crc: Long
        try {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalStateException("無法讀取檔案")
            nes = Nes(bytes)
            crc = CRC32().also { it.update(bytes) }.value
        } catch (e: Throwable) {
            onError(e.message ?: e.toString())
            return
        }
        romCrc = crc
        applyVblank()

        // 載入此遊戲已啟用的金手指
        try {
            applyCheats(CheatStore.load(context, crc))
        } catch (_: Throwable) {
        }

        val sramFile = File(File(context.filesDir, "sram").also { it.mkdirs() }, "%08x.sav".format(crc))
        if (nes.cart.hasBattery) loadSram(nes, sramFile)

        val bitmap = Bitmap.createBitmap(256, 240, Bitmap.Config.ARGB_8888)
        val track = createTrack()
        track?.play()

        val frameNanos = 16_639_267L // 1e9 / 60.0988
        var next = System.nanoTime()
        var lastPaused = false
        var prevLimiter = true
        var audioFailed = false
        var framesSinceSave = 0
        var blankHold = 0
        var rewindTick = 0

        while (running) {
            while (true) {
                val t = tasks.poll() ?: break
                t(nes)
            }

            if (paused) {
                if (!lastPaused) {
                    track?.pause()
                    lastPaused = true
                }
                sleep(30)
                next = System.nanoTime()
                continue
            }
            if (lastPaused) {
                track?.play()
                lastPaused = false
            }

            if ((input() and Pad.REWIND) != 0 && rewindBuf.isNotEmpty()) {
                // 倒轉：每個畫面往回一格快照（約 3 幀），不出聲
                try {
                    nes.loadState(rewindBuf.removeLast())
                    nes.runFrame()
                    nes.apu.sampleCount = 0
                    bitmap.setPixels(nes.ppu.frame, 0, 256, 0, 0, 256, 240)
                    gameView.drawFrame(bitmap)
                } catch (_: Throwable) {
                    rewindBuf.clear()
                }
                if (!prevLimiter) next = System.nanoTime()
                prevLimiter = true
                next += frameNanos
                val w = next - System.nanoTime()
                if (w > 0) sleep(w / 1_000_000L, (w % 1_000_000L).toInt()) else if (w < -frameNanos * 5) next = System.nanoTime()
                continue
            }

            val mult = if (settings.fastForward) settings.ffMultiplier else 1
            for (k in 0 until mult) {
                nes.setPad(player, effectiveInput())
                nes.setPad(1 - player, 0)
                frameCounter++
                nes.runFrame()
                if (k < mult - 1) nes.apu.sampleCount = 0
            }
            if (++rewindTick >= 3) {
                rewindTick = 0
                try {
                    rewindBuf.addLast(nes.saveState())
                    if (rewindBuf.size > 300) rewindBuf.removeFirst()
                } catch (_: Throwable) {
                }
            }

            // 防閃爍：這一幀渲染不完整（遊戲暫時關閉畫面去更新資料）時，沿用上一張完整畫面；
            // 最多連續沿用 12 幀，避免真的需要全黑的場面卡住
            if (nes.ppu.renderedLines >= 200 || blankHold >= 12 || !settings.antiFlicker) {
                blankHold = 0
                bitmap.setPixels(nes.ppu.frame, 0, 256, 0, 0, 256, 240)
            } else {
                blankHold++
            }
            gameView.drawFrame(bitmap)

            // 一般速度：用音訊寫入控制節奏；快轉時不輸出聲音
            val apu = nes.apu
            var audioOk = false
            if (mult == 1 && track != null && !audioFailed && apu.sampleCount > 0) {
                audioOk = track.write(apu.samples, 0, apu.sampleCount) >= 0
                if (!audioOk) audioFailed = true
            }
            apu.sampleCount = 0

            val limiter = !audioOk
            if (limiter && !prevLimiter) next = System.nanoTime()
            prevLimiter = limiter
            if (limiter) {
                next += frameNanos
                val wait = next - System.nanoTime()
                if (wait > 0) {
                    sleep(wait / 1_000_000L, (wait % 1_000_000L).toInt())
                } else if (wait < -frameNanos * 5) {
                    next = System.nanoTime()
                }
            }

            if (nes.cart.hasBattery && ++framesSinceSave >= 60 * 30) {
                framesSinceSave = 0
                saveSram(nes, sramFile)
            }
        }

        try {
            track?.stop()
            track?.release()
        } catch (_: Throwable) {
        }
        if (nes.cart.hasBattery) saveSram(nes, sramFile)
    }

    private fun createTrack(): AudioTrack? = try {
        val rate = 44100
        val minBuf = AudioTrack.getMinBufferSize(
            rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuf, 8192))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
    } catch (_: Throwable) {
        null
    }

    private fun loadSram(nes: Nes, file: File) {
        try {
            if (file.exists()) {
                val data = file.readBytes()
                System.arraycopy(data, 0, nes.mapper.prgRam, 0, minOf(data.size, nes.mapper.prgRam.size))
            }
        } catch (_: Throwable) {
        }
    }

    private fun saveSram(nes: Nes, file: File) {
        try {
            file.writeBytes(nes.mapper.prgRam)
        } catch (_: Throwable) {
        }
    }
}
